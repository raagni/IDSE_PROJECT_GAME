# Echo Point — playtest record

Copy this section once for each peer.

**Participant ID:**            **Date:**            **Device / browser:**

## Quiz scores (from PLAYTEST in the game)
| Pre-game quiz (/6) | Post-game quiz (/6) | Change |
|---|---|---|
|   |   |   |

## Per chapter (from EXPORT CSV)
| Chapter | Completed? | Rewinds used | Hints | Time (s) | Rank |
|---|---|---|---|---|---|
| 1 Rosie's Diner (mean/median) | | | | | |
| 2 Basement (outliers) | | | | | |
| 3 KECO Radio (correlation) | | | | | |
| 4 Hollow Woods (K-means) | | | | | |
| 5 Lighthouse (regression/overfitting) | | | | | |

## Feedback
- What was fun?
- What was confusing?
- One thing you learned, in your own words:
- Would you play again? (yes / no / maybe)

## Observer notes
- Where did they get stuck?
- Did they discover the concept by playing, or did they read the answer?

## Change made because of this feedback
-
