# Echo Point — a data thriller

A psychological-thriller game in which you learn data-science concepts by playing. Each chapter is a mystery that can only be solved by testing ideas against data. Reading the answer or guessing won't get you through.

## How to run
Double-click **`echo_point.html`** to open it in Chrome, Edge, Firefox or Safari. Nothing needs installing, and it works offline.
Headphones are recommended, because the music and sound effects change with what is happening in the game.

## The story
It has rained in Echo Point for nine days. Mira's best friend Jun vanished five days ago, and he was investigating numbers that "didn't add up". Mira has also discovered she can **rewind time** a few times. Each of the five places in town hides a data mystery, and solving it reveals a clue that leads to Jun.

## How to play
| Key | Action |
|---|---|
| A / D or ← → | Walk (hold **Shift** to run) |
| W | Jump |
| E or click | Interact: talk, pick up, read, open a puzzle, move the dialogue on |
| H | Hint |
| M | Case Board (map) |
| J | Case Notes (learning book) |
| Esc | Pause / settings (volume, voice, difficulty, bigger text, reduced motion) |

1. Choose an unlocked chapter on the **Case Board**.
2. Talk to the person at the left edge of the scene, then collect every glowing item and read every note. The puzzle stays locked until you have done this.
3. Open the puzzle (the laptop, control panel, data wall, ping map or lamp room) and solve it.
4. **Wrong decisions cost a rewind.** You have 3 per chapter. You see what went wrong, time rewinds, and you choose again. If you run out, the chapter restarts.
5. Each chapter ends with a **clue**, a rank from **S to C** (based on rewinds and hints used) and a **Mind Palace** animation that replays the concept using the numbers from your own game.
6. When you have all five clues, open the final chapter from the Case Board.

The **📅 DAILY** button gives everyone the same puzzles for the day, and **SHARE** copies a result card. Turn daily mode off to get new random data every time.

## Learning objectives
By the end of the game, the player can:
1. Work out the **mean, median and mode** and explain why one extreme value drags the mean but barely moves the median.
2. Spot **outliers** with the IQR rule, then decide whether to remove one (a sensor glitch) or keep it (a real event) by **checking the cause**.
3. Read the **correlation coefficient r** and explain why **correlation is not causation**, recognising a **confounder**.
4. Explain how **K-means clustering** works (assign to the nearest centre, move each centre to the mean of its group) and choose k using the **elbow** method.
5. Fit and use a **linear regression** line to predict new values.
6. Explain **overfitting** (a model that fits old data perfectly can predict new data badly) and why **extrapolation** far from the data is uncertain.

## Chapters and concepts
| Chapter | Place | Concept | What the player does |
|---|---|---|---|
| 1 | Rosie's Diner | Mean, median, mode | Predicts which number a giant salary will move, tests it by adding the pay, then chooses the honest "typical pay". |
| 2 | Echo High basement | Outliers, IQR | Inspects sensor histories and backup gauges, removes the glitch and keeps the real surge, then runs the cooling test. |
| 3 | KECO Radio | Correlation vs causation | Drags data points and watches r change, adds the weather variable, then rates a viral headline as true, false or confounded. |
| 4 | Hollow Woods | K-means clustering | Runs K-means step by step for k = 2, 3 and 4, then reads the elbow chart to decide how many places Jun went. |
| 5 | The Lighthouse | Regression, overfitting, extrapolation | Predicts the next sightings, chooses between a straight line and a "perfect" curve, then picks a search width for a far-future prediction. |

## How the game works
- **Real computation, no hard-coded answers:** every dataset is generated at random (or from the daily seed) and checked to be solvable. Mean, median, quartiles/IQR, Pearson r, OLS regression, K-means/WCSS and Lagrange interpolation (the overfitting curve) are all calculated live.
- **Decisions change the outcome:** wrong calls cost rewinds, and losing all three restarts the chapter with new data.
- **Exploration matters:** each puzzle stays locked until the player has talked to the character, collected the evidence and read the notes.

## Playtest evidence
- In the Case Board, the **PLAYTEST** button gives a pre-game quiz and a post-game quiz (6 questions each, with different questions after the game), a feedback form, and per-chapter attempts, hints and time.
- **EXPORT CSV / JSON** saves the results. If the download is blocked, the game shows the text with a COPY button instead.
- Fill in `PLAYTEST_TEMPLATE.md` for each peer who plays.

## Files
| File | What it is |
|---|---|
| `echo_point.html` | The complete game (a single self-contained file). |
| `README.md` | This guide. |
| `PLAYTEST_TEMPLATE.md` | A form for recording each peer playtest. |
| `screenshots/` | Images from the game. |
| `source/base_game.html` | The original base game the layers are built on. |
| `source/explorer.js` | The base character drawing code. |
| `source/patch.js` | Bug fixes, rewinds and ranks, puzzle redesigns, the overfitting boss, quizzes, daily mode and sharing. |
| `source/thriller.js` | The Echo Point story, animated characters, scenes, weather, cutscenes, the rewind effect and the Case Board. |
| `source/fx.js` | Adaptive music, sound effects, the cinematic camera, footsteps and the Mind Palace replays. |
| `source/edit_src.py` | The build script: `cp base_game.html echo_point.html && python3 edit_src.py echo_point.html` rebuilds the game. |

## Known limitations
- The game is 2D side-on, drawn in code. It has no 3D models.
- It hasn't been tested on phones.
- Spoken lines use the browser's built-in voice, which differs between devices.
