// ============================================================================
// v2 PATCH: fixes stale text, removes giveaways, adds hearts/ranks, daily mode,
// overfitting boss, random forest data, better animation and a Gen Z tone.
// All names here start with gz to avoid clashing with earlier scripts.
// ============================================================================

// ---------- styles ----------
document.head.insertAdjacentHTML('beforeend', `<style>
#gz-fade{position:fixed;inset:0;background:#04070f;z-index:900;pointer-events:none;opacity:0;transition:opacity .45s ease}
#gz-fx{position:fixed;inset:0;z-index:800;pointer-events:none}
.ancient-modal-backdrop.active .ancient-mechanism-frame,.dd-overlay.on .dd-card{animation:gzpop .32s cubic-bezier(.2,.9,.3,1.15)}
@keyframes gzpop{from{opacity:0;transform:translateY(14px) scale(.96)}}
.gz-hit{animation:gzhit .45s}
@keyframes gzhit{0%,100%{transform:none}20%{transform:translateX(-9px)}40%{transform:translateX(8px)}60%{transform:translateX(-5px)}80%{transform:translateX(3px)}}
#gz-redflash{position:fixed;inset:0;z-index:850;pointer-events:none;background:radial-gradient(circle,transparent 40%,rgba(239,68,68,.55));opacity:0;transition:opacity .5s}
.gz-hearts{font-size:1rem;letter-spacing:2px;white-space:nowrap}
.gz-hearts .lost{filter:grayscale(1) brightness(.5)}
.gz-hearts .pop{display:inline-block;animation:gzheart .6s}
@keyframes gzheart{30%{transform:scale(1.8) rotate(-12deg)}100%{transform:scale(1)}}
.gz-rank{font-family:Georgia,serif;font-size:4.2rem;font-weight:bold;text-align:center;line-height:1;margin:4px 0;animation:gzrank .8s cubic-bezier(.2,.9,.3,1.4)}
@keyframes gzrank{from{transform:scale(3) rotate(-20deg);opacity:0}}
.gz-choice{display:flex;gap:8px;flex-wrap:wrap;margin:6px 0}
.gz-panel{background:rgba(9,14,26,.85);border:1px solid rgba(245,215,110,.55);border-radius:12px;padding:10px 12px;margin:8px 0;font-size:.9rem;line-height:1.5}
.gz-good{color:#2dd4bf}.gz-bad{color:#fca5a5}.gz-warn{color:#fcd34d}
.gz-pulse{animation:gzpl .9s 2}
@keyframes gzpl{50%{box-shadow:0 0 0 4px rgba(245,215,110,.6)}}
body.rm #gz-fade,body.reduced-motion #gz-fade{transition:none}
</style>`);
document.body.insertAdjacentHTML('beforeend', '<div id="gz-fade"></div><canvas id="gz-fx"></canvas><div id="gz-redflash"></div>');
const gzRM = () => document.body.classList.contains('rm') || document.body.classList.contains('reduced-motion');

// ---------- effects: shake, confetti, flash, fade ----------
const gzShake = { a: 0 };
function gzShakeIt(a) { if (!gzRM()) gzShake.a = Math.max(gzShake.a, a); }
const gzFX = { c: $d('gz-fx'), p: [], run: false };
function gzFxSize() { gzFX.c.width = innerWidth; gzFX.c.height = innerHeight; }
addEventListener('resize', gzFxSize); gzFxSize();
function gzConfetti(n) {
  if (gzRM()) return;
  const cols = ['#f5d76e', '#2dd4bf', '#a855f7', '#f43f5e', '#38bdf8', '#fffbeb'];
  for (let i = 0; i < (n || 140); i++) gzFX.p.push({ x: innerWidth / 2 + (Math.random() - .5) * 120, y: innerHeight * .35, vx: (Math.random() - .5) * 16, vy: -6 - Math.random() * 10, r: Math.random() * 6.28, vr: (Math.random() - .5) * .4, w: 5 + Math.random() * 6, h: 3 + Math.random() * 5, c: cols[i % cols.length], life: 1 });
  if (!gzFX.run) { gzFX.run = true; requestAnimationFrame(gzFxLoop); }
}
function gzFxLoop() {
  const g = gzFX.c.getContext('2d'); g.clearRect(0, 0, gzFX.c.width, gzFX.c.height);
  gzFX.p.forEach(p => { p.vy += .32; p.vx *= .99; p.x += p.vx; p.y += p.vy; p.r += p.vr; p.life -= .006;
    g.save(); g.globalAlpha = Math.max(0, Math.min(1, p.life * 1.5)); g.translate(p.x, p.y); g.rotate(p.r); g.scale(1, Math.abs(Math.cos(p.r * 2)) + .2); g.fillStyle = p.c; g.fillRect(-p.w / 2, -p.h / 2, p.w, p.h); g.restore(); });
  gzFX.p = gzFX.p.filter(p => p.life > 0 && p.y < innerHeight + 30);
  if (gzFX.p.length) requestAnimationFrame(gzFxLoop); else { gzFX.run = false; g.clearRect(0, 0, gzFX.c.width, gzFX.c.height); }
}
function gzRedFlash() { const f = $d('gz-redflash'); f.style.transition = 'none'; f.style.opacity = 1; void f.offsetWidth; f.style.transition = 'opacity .6s'; f.style.opacity = 0; }
function gzFadeIn() { if (gzRM()) return; const f = $d('gz-fade'); f.style.transition = 'none'; f.style.opacity = 1; void f.offsetWidth; f.style.transition = 'opacity .5s ease'; f.style.opacity = 0; }
function gzPulse(el) { if (!el) return; el.classList.remove('gz-pulse'); void el.offsetWidth; el.classList.add('gz-pulse'); }

// ---------- hearts ----------
const gzHP = { lv: 0, h: 3, max: 3, dead: false };
{ const c = document.querySelector('#top-hud .hud-cluster'); if (c) c.insertAdjacentHTML('beforeend', '<span id="hud-hearts" class="gz-hearts" title="Hearts: a wrong decision costs one"></span>'); }
{ const hb = $d('btn-modal-hint'); if (hb) hb.insertAdjacentHTML('beforebegin', '<span id="modal-hearts" class="gz-hearts" style="margin-right:10px"></span>'); }
function gzHeartsHTML(pop) { let s = ''; for (let i = 0; i < gzHP.max; i++) s += '<span class="' + (i >= gzHP.h ? 'lost ' : '') + (pop && i === gzHP.h ? 'pop' : '') + '">❤️</span>'; return s; }
function gzHpRender(pop) { ['hud-hearts', 'modal-hearts'].forEach(id => { const e = $d(id); if (e) e.innerHTML = gzHeartsHTML(pop); }); }
function gzHpReset(i) { gzHP.lv = i; gzHP.h = gzHP.max; gzHP.dead = false; gzHpRender(); }
function gzLoseHeart(why) {
  if (gzHP.dead || gzHP.h <= 0) return;
  gzHP.h--; gzHpRender(true);
  gzShakeIt(14); gzRedFlash();
  const fr = document.querySelector('.ancient-mechanism-frame'); if (fr && !gzRM()) { fr.classList.remove('gz-hit'); void fr.offsetWidth; fr.classList.add('gz-hit'); }
  soundFX.playTone(150, .35, 'sawtooth', .25, 0); soundFX.playTone(98, .5, 'triangle', .25, .1);
  if (why) showToast('💔 ' + why);
  if (gzHP.h <= 0) { gzHP.dead = true; setTimeout(gzLevelFail, 1300); }
}
function gzLevelFail() {
  const i = gzHP.lv; closeAncientModal();
  const o = ddOverlay('dd-fail', '<h2>OUT OF HEARTS 💀</h2><p class="dd-ari" style="font-size:1.05rem"><b>Ari:</b> ok that one hurt. but every miss showed us something about the data.</p><p style="text-align:center">Try again: you start with 3 hearts' + (gzDM.on ? ' and the same daily data.' : ' and brand new data.') + '</p><div class="dd-row"><button class="dd-btn" id="gz-f-home">HOME</button><button class="dd-btn main" id="gz-f-retry">TRY AGAIN</button></div>');
  ddSay('oops', 'ari', true);
  $d('gz-f-home').onclick = () => { o.classList.remove('on'); showWorldMap(); };
  $d('gz-f-retry').onclick = () => { o.classList.remove('on'); gameState.regions[i] = INITIAL_GAME_STATE().regions[i]; saveGameState(); enterRegion(i); };
}
function gzIsLive() { return !gzHP.dead && gzHP.h > 0; }

// ---------- daily mode ----------
const gzDM = (() => { let on = true; try { const v = localStorage.getItem('gz_daily'); if (v !== null) on = v === '1'; } catch (e) {} return { on, entering: false }; })();
function gzToday() { const d = new Date(); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }
function gzDayNum() { const d = new Date(); return Math.floor((Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()) - Date.UTC(2026, 0, 1)) / 864e5) + 1; }
function gzDailySeed(k) { let h = 2166136261; const s = gzToday() + '|' + k; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return 100000 + ((h >>> 0) % 900000); }
{ const _ds = ddSeed; ddSeed = function (k, force) { if (!force && gzDM.on && gzDM.entering) force = gzDailySeed(k); return _ds(k, force); }; }
{ const _ln = ddL1New; ddL1New = function (seed) { if (!seed && gzDM.on && gzDM.entering) seed = gzDailySeed('temple'); _ln(seed); L1.gzPred = null; L1.gzPredOK = false; L1.gzVerdict = false; L1.gzRevealed = false; }; }

// ---------- ranks and results ----------
function gzRankOf(h, hints) { if (h === 3 && hints === 0) return 'S'; if (h >= 2 && hints <= 1) return 'A'; if (h >= 1 && hints <= 3) return 'B'; return 'C'; }
const gzRankCol = { S: '#f5d76e', A: '#2dd4bf', B: '#a855f7', C: '#f87171' };
const gzRankEmoji = { S: '🟩', A: '🟨', B: '🟧', C: '🟥' };
function gzRes() { try { return JSON.parse(localStorage.getItem('gz_results') || '{}'); } catch (e) { return {}; } }
function gzSaveRes(i, rank, h) {
  const r = gzRes(), day = gzDM.on ? gzToday() : 'free';
  r[day] = r[day] || {}; const old = r[day][i];
  const order = 'SABC'; if (!old || order.indexOf(rank) < order.indexOf(old.rank)) r[day][i] = { rank, h };
  r.best = r.best || {}; if (!r.best[i] || order.indexOf(rank) < order.indexOf(r.best[i])) r.best[i] = rank;
  try { localStorage.setItem('gz_results', JSON.stringify(r)); } catch (e) {}
}

// ---------- Gen Z tone ----------
const gzIntro = [
  'ok so the temple priest says the "average" pay here is amazing. kinda sus. let\'s check the numbers.',
  'it\'s giving overheating. one of these sensors is lying. find it before the furnace blows.',
  'a viral headline says ice cream makes people go swimming. we\'re not falling for that. let\'s look at the data.',
  'these creatures are lost and honestly so are we. let\'s sort them into groups that make sense.',
  'boss fight. it attacks in a pattern. learn the pattern, don\'t panic.'];
REALMS.forEach((r, i) => r.ariaIntro = gzIntro[i]);
REALMS[0].shortDesc = 'Catch an "average" that lies about pay.';
REALMS[1].shortDesc = 'Find the lying sensor before the furnace blows.';
REALMS[2].shortDesc = 'Debunk a viral headline with data.';
REALMS[3].shortDesc = 'Group the lost creatures — and pick how many groups.';
REALMS[4].shortDesc = 'Boss fight: predict its attacks, dodge its trap.';
DD_INTRO.splice(0, DD_INTRO.length,
  'The Lost Kingdom used to glow. Then the Kingdom Heart shattered into five Power Crystals and the lights went out.',
  'Each crystal is stuck behind a problem: a lying average, a glitching sensor, a fake headline, lost creatures, and a boss.',
  'You can\'t guess your way through. You get 3 hearts per level, and wrong calls cost one.',
  'Ari (tiny light spirit, big opinions) is coming with you. Ready?');
DD_CHEER.splice(0, 5, 'Door\'s open. The average got exposed.', 'Furnace saved. No fake data, no missed danger.', 'Headline debunked. Bridge rebuilt.', 'Creatures sorted. The forest approves.', 'Boss down. You predicted the future (responsibly).');
DDV.L.ari = ['look over there', 'you got this', 'check the glowing stuff', 'evidence first, vibes second'];
DDV.L.win = ['clean.', 'no notes.', 'that\'s the one.', 'big W.'];
DDV.L.oops = ['nope, that cost us.', 'not it. try again.', 'hmm. look closer.'];
DDV.L.cheer = ['yes. that works.', 'nice one.'];
DDV.L.jump = ['hup', 'hop'];
DDV.L.land = ['nice'];
if ('speechSynthesis' in window) { const _sp = speechSynthesis.speak.bind(speechSynthesis); speechSynthesis.speak = u => { if (u.pitch > 1.4) u.pitch = 1.25; if (u.rate > 1.1) u.rate = 1.05; _sp(u); }; }

DD_SHORT[0] = ['The priest says the average pay is "amazing". Prove whether an average can lie.', ['Pick up all 5 pay slips and read the sign (press E).', 'At the Stone Table: predict, test, then decide which number is honest.', 'Wrong calls cost a heart. You have 3.']];
DD_SHORT[1] = ['One sensor is lying. Another is warning you for real. Tell them apart before the furnace blows.', ['Grab the crystals and read both reports.', 'At the Furnace Control, inspect each odd sensor: history and backup gauge.', 'Keep real readings, remove broken ones, then run the cooling test.']];
DD_SHORT[2] = ['A viral headline: "Buying ice cream makes people go swimming!" Debunk it with data.', ['Grab the star pieces and read the note.', 'At the Star Map, drag stars and watch r change.', 'Open the ice cream data, add hot weather, then rate the headline.']];
DD_SHORT[3] = ['The creatures are lost. Group them — and decide how many groups is actually right.', ['Find the 3 magic stones and read the note.', 'At the Forest Map, run K-means with 2, 3 and 4 groups.', 'Read the elbow chart and choose the best number of groups.']];
DD_SHORT[4] = ['Boss fight in 3 phases. Learn its pattern, avoid its trap, survive the far attack.', ['Read all 3 tablets (press E).', 'At the Prediction Staff, predict two attacks.', 'Then face the "perfect curve" deal and the far attack.']];

DD_HINTS[0] = ['Pick up all 5 pay slips and read the sign, then go to the Stone Table.', 'Press each stone. The mean uses the TOTAL of every value. What happens to a total when one giant value joins?', 'The mean gets dragged by one giant value; the median only looks at the middle. Type a big pay like 500, then pick the honest number.'];
DD_HINTS[1] = ['Read both Temperature Reports, then go to the Furnace Control.', 'Click the sensor marked ⚠. Did it jump suddenly, or climb step by step? Check its backup gauge too.', 'Sudden jump + backup gauge disagrees = broken, remove it. Step-by-step climb + backup agrees = real, keep it.'];
DD_HINTS[2] = ['Grab the star pieces, read the note, then open the Star Map.', 'Drag one star far away and watch r. Then open ICE CREAM & SWIMMING.', 'Press ADD HOT WEATHER. If r is weak inside each weather group, weather drives both. Rate the headline "confounded".'];
DD_HINTS[3] = ['Grab the 3 magic stones and read the note, then open the Forest Map.', 'For 2, 3 and 4 groups: press MOVE GROUPS until the centres stop moving.', 'On the elbow chart, pick where adding one more group stops helping much.'];
DD_HINTS[4] = ['Read all 3 tablets, then go to the Prediction Staff.', 'Imagine a straight line through the dots and extend it. SHOW BEST-FIT LINE helps (counts as a hint).', 'Trust the simple line, not the curve that hits every old point. Far away from the data, use the wide shield.'];
REALMS[0].ariaHint = 'Predict MEAN, type a giant number (like 500) and ADD it, then pick MEDIAN as the honest pay.';
REALMS[1].ariaHint = 'Furnace 1: the sensor that jumped suddenly and whose backup gauge disagrees is broken — remove it. Furnace 2: the climbing one is real — keep it. Then run the test.';
REALMS[2].ariaHint = 'Drag a star, open ICE CREAM & SWIMMING, press ADD HOT WEATHER, then choose "Confounded".';
REALMS[3].ariaHint = 'Run 2, 3 and 4 groups until the centres stop, press FINISH, and choose the elbow (3 groups).';
REALMS[4].ariaHint = 'Place your marker on the best-fit line for attacks 7 and 8, pick the STRAIGHT LINE in the deal, then pick the WIDE shield.';

// Learning Book: rewrite entries so they match what the player actually does now
Object.assign(CODEX_ENTRIES.sunken_order, {
  title: '1. When "average" lies: mean, median, mode',
  fantasyLore: 'The priest\'s poster said the average pay was amazing. It was true — because his own giant pay was in the list.',
  explanation: 'The mean adds up every value, so one giant value drags it. The median only looks at the middle of the sorted list, so it barely moves. For skewed data like pay, the median shows the typical value better.',
  playerAction: 'You predicted which number a giant pay would move most, added it yourself, watched the mean jump while the median barely moved, and picked the median as the honest typical pay.',
  realWorld: 'Job ads and news about "average salary" or "average house price" can be pulled up by a few huge values. The median is usually fairer.'
});
Object.assign(CODEX_ENTRIES.ember_outlier_error, {
  fantasyLore: 'In Furnace 1, one sensor jumped suddenly to a huge reading while the backup gauge beside it stayed normal. The reading was wrong.',
  mathPrinciple: 'IQR rule: unusual if below Q1 − 1.5×IQR or above Q3 + 1.5×IQR. Then check the cause before removing it.',
  playerAction: 'You checked the odd sensor\'s history (a sudden jump) and its backup gauge (normal), decided it was faulty, removed it and passed the cooling test.'
});
Object.assign(CODEX_ENTRIES.ember_outlier_surge, {
  fantasyLore: 'In Furnace 2, one reading climbed step by step and its backup gauge agreed. The heat was real.',
  playerAction: 'You kept the real high reading, so the cooling system started and the furnace was saved.'
});
Object.assign(CODEX_ENTRIES.astral_correlation, {
  fantasyLore: 'Each star is a data point. Some star groups rise together, some move opposite, some have no pattern.',
  playerAction: 'You dragged and added stars and watched r change — including how one far-away star can change r a lot.'
});
Object.assign(CODEX_ENTRIES.astral_causation, {
  title: '5. The viral headline: correlation is not cause',
  fantasyLore: 'A headline claimed "Buying ice cream makes people go swimming!" Both really do rise together — on hot days.',
  explanation: 'When you hold the weather about the same, the link mostly disappears. Hot weather drives both, so it is a confounder (a hidden third factor).',
  playerAction: 'You compared r overall with r on similar-weather days and rated the headline as confounded.',
  realWorld: 'Ice cream sales and sunburns rise together, but the hot sun causes both.'
});
Object.assign(CODEX_ENTRIES.wilds_kmeans, {
  mathPrinciple: 'Nearest centre decides the group. New centre = average position of its group. Elbow rule: choose k where the WCSS drop flattens.',
  playerAction: 'You ran K-means with 2, 3 and 4 groups, read the elbow chart, and chose the number of groups where adding one more stopped helping much.'
});
Object.assign(CODEX_ENTRIES.throne_regression, {
  explanation: 'A straight line through past points predicts the next points. The further you predict from the data you have, the less certain the prediction is, so you need a wider safety margin.',
  playerAction: 'You predicted the monster\'s attacks from past data, and used a wider shield for the far-away attack because extrapolation is risky.'
});
CODEX_ENTRIES.throne_overfit = {
  id: 'throne_overfit', title: '8. The perfect-curve trap (overfitting)', region: 'Dark Castle',
  fantasyLore: 'The monster offered a curve that passed through every past attack exactly. It looked perfect. It was a trap.',
  dsConcept: 'A model that fits past data too closely learns the noise, not the pattern. This is overfitting.',
  explanation: 'The straight line has small errors on the old data but predicts new data well. The wiggly curve has zero error on the old data but a big error on new data. Low training error does not mean good predictions.',
  mathPrinciple: 'Judge a model on new data (test error), not only on the data it was fitted to (training error).',
  playerAction: 'You compared the straight line with the "perfect" curve and chose which one to trust for the next attack.',
  realWorld: 'A student who memorises last year\'s exam answers can fail a new exam. A model that memorises its data fails on new data.'
};
DD_LEARN[0] = ['You predicted, then tested what one giant pay does to the mean, median and mode, and chose the honest number.', 'Concept: mean, median and mode. One extreme value drags the mean but barely moves the median.', 'Real life: "average salary" headlines can be pulled up by a few huge pays.'];
DD_LEARN[4] = ['You predicted attacks from past data, refused the overfitted curve, and widened your shield for the far attack.', 'Concept: regression predicts new values; overfitting fits noise; extrapolation is uncertain.', 'Real life: delivery apps predict arrival times, and get less sure the further ahead they predict.'];
DD_BRIEF[0] = 'One giant value drags the mean a lot but barely moves the median. That is how an "average" can lie.';
DD_BRIEF[4] = 'A line fitted to past data predicts the future. A curve that fits the past perfectly can predict it terribly (overfitting), and far predictions need wider margins.';

// ---------- exploration matters: puzzles stay locked until you collect/read everything ----------
{ const _gro = getRegionWorldObjects; getRegionWorldObjects = function (i) {
    const o = _gro(i), miss = o.filter(x => x.type !== 'mechanism' && !x.collected).length;
    o.forEach(x => { if (x.type === 'mechanism' && !x.solved && miss > 0) x.onInteract = () => { setAriaSpeech('locked. we still need ' + miss + ' more thing' + (miss > 1 ? 's' : '') + ' from this area — follow the glowing markers.', 5000); ddSay('oops', 'ari', true); soundFX.playGuardianPulse(); }; });
    return o; }; }

// ---------- level entry / completion hooks ----------
{ const _er = enterRegion; enterRegion = function (i) {
    if (!gameState.unlockedRegions[i]) return _er(i);
    gzHpReset(i); gzFadeIn();
    gzDM.entering = true; try { if (i === 3) gzForestNew(); if (i === 4) gzCaNew(); _er(i); } finally { gzDM.entering = false; }
    gzHpRender(); }; }
{ const _sw = showWorldMap; showWorldMap = function () { gzFadeIn(); _sw(); }; }
{ const _slc = showLevelComplete; showLevelComplete = function (i) {
    _slc(i);
    const rank = gzRankOf(gzHP.h, ddHintCount); gzSaveRes(i, rank, gzHP.h);
    const h2 = document.querySelector('#dd-complete .dd-card h2');
    if (h2) h2.insertAdjacentHTML('afterend', '<div class="gz-rank" style="color:' + gzRankCol[rank] + ';text-shadow:0 0 24px ' + gzRankCol[rank] + '">' + rank + '</div><p style="text-align:center;margin:0">' + gzHeartsHTML() + ' &nbsp;•&nbsp; hints used: ' + ddHintCount + '</p><p style="text-align:center;font-size:.8rem;color:#9ba3b5;margin:2px 0 6px">S = no hearts lost and no hints</p>');
    gzConfetti(160); }; }

// ---------- NUMBER TEMPLE: predict → test → decide ----------
{ const _osm = openSunkenMechanism; openSunkenMechanism = function () {
    _osm();
    const boxes = $d('modal-body').querySelectorAll('.ancient-carving-box');
    if (boxes[0]) boxes[0].innerHTML = '<div class="carving-subtitle">The pay poster</div><p style="font-size:.9rem;line-height:1.55">These are the gold coins 9 temple workers earned this week. The priest\'s poster says <b>"Average pay here: amazing!"</b> — but he sneaks his own giant pay into the list. Can an "average" lie?</p><ol style="font-size:.86rem;line-height:1.5;padding-left:20px"><li>Press the three stones to see how each number is worked out.</li><li><b>Predict</b> what the priest\'s pay will do.</li><li><b>Test</b> it: type his pay and press ADD.</li><li><b>Decide</b> which number is honest. Wrong calls cost a heart.</li></ol>';
    if (boxes[1]) { const p = boxes[1].querySelector('p'); if (p) p.innerHTML = 'Add <b>one</b> number (the priest\'s pay) so the <b>mean</b> moves by 8 or more but the <b>median</b> moves less than half as much.'; }
    const huge = $d('l1-huge'); if (huge) huge.remove();
    const inp = $d('l1-in'); if (inp) inp.placeholder = 'his pay';
    $d('l1-nums').insertAdjacentHTML('beforebegin', '<div id="gz-pred" class="gz-panel"></div>');
    $d('l1-open').parentNode.insertAdjacentHTML('beforebegin', '<div id="gz-verdict" class="gz-panel" style="display:none"></div>');
    const add = $d('l1-add').onclick;
    $d('l1-add').onclick = () => { if (!L1.gzPred) { showToast('Predict first! Pick one above.'); gzPulse($d('gz-pred')); return; } add(); };
    gzPredRender(); ddL1Update(); }; }
function gzPredRender() {
  const el = $d('gz-pred'); if (!el) return;
  const nm = { mean: 'MEAN', median: 'MEDIAN', mode: 'MODE' };
  if (!L1.gzPred) {
    el.innerHTML = '<b>🔮 PREDICT FIRST:</b> the priest adds his own GIANT pay to the list. Which number will jump the most?<div class="gz-choice"><button class="runic-btn" data-gp="mean">Mean</button><button class="runic-btn" data-gp="median">Median</button><button class="runic-btn" data-gp="mode">Mode</button></div>';
    el.querySelectorAll('[data-gp]').forEach(b => b.onclick = () => { L1.gzPred = b.dataset.gp; L1.gzPredOK = b.dataset.gp === 'mean'; soundFX.playMechanismClick(); gzPredRender(); ddL1Update(); });
  } else {
    el.innerHTML = '<b>🔮 Your prediction:</b> ' + nm[L1.gzPred] + ' jumps the most.' + (L1.gzRevealed ? (L1.gzPredOK ? ' <span class="gz-good">✔ Called it.</span>' : ' <span class="gz-bad">✖ It was the MEAN — it adds up every value, so one giant value drags it.</span>') : ' <span style="color:#9ba3b5">Now test it: type his pay and press ADD.</span>');
  }
}
{ const _u = ddL1Update; ddL1Update = function () {
    _u();
    const ch = !!L1.ok; L1.gzCh = ch;
    if (ch && L1.gzPred && !L1.gzRevealed) { L1.gzRevealed = true; if (!L1.gzPredOK) gzLoseHeart('Prediction missed: the MEAN moved most.'); else { ddSay('cheer', 'ari', true); showToast('Prediction confirmed ✔'); } }
    L1.ok = ch && !!L1.gzVerdict && !!L1.gzPred;
    const open = $d('l1-open'); if (open) { open.disabled = !L1.ok; open.style.opacity = L1.ok ? 1 : .45; }
    const v = $d('gz-verdict');
    if (v) {
      v.style.display = ch ? 'block' : 'none';
      if (ch && !L1.gzVerdict) {
        v.innerHTML = '<b>⚖️ DECIDE:</b> a new worker wants to know what a <b>typical</b> worker here really earns. Which number should they trust?<div class="gz-choice"><button class="runic-btn" data-gv="mean">Mean</button><button class="runic-btn" data-gv="median">Median</button><button class="runic-btn" data-gv="mode">Mode</button></div><div id="gz-vmsg"></div>';
        v.querySelectorAll('[data-gv]').forEach(b => b.onclick = () => {
          if (b.dataset.gv === 'median') { L1.gzVerdict = true; soundFX.playCollect(); ddL1Update(); }
          else { gzLoseHeart(b.dataset.gv === 'mean' ? 'The mean is the number the priest is using to brag.' : 'The mode is only the most repeated value.'); const m = $d('gz-vmsg'); if (m) m.innerHTML = '<span class="gz-bad">' + (b.dataset.gv === 'mean' ? '✖ The mean got dragged up by one giant pay — that\'s exactly the trick on the poster.' : '✖ The mode is just the value that appears most. It can sit anywhere, not at the typical middle.') + '</span>'; }
        });
      } else if (L1.gzVerdict) v.innerHTML = '<span class="gz-good">✔ Median. It ignores how huge the priest\'s pay is and shows the middle worker. Press OPEN THE DOOR.</span>';
    }
    const g = $d('l1-goal');
    if (g) { if (L1.ok) { g.textContent = '✔ Exposed! One giant value dragged the mean, the median stayed honest.'; g.style.color = '#2dd4bf'; }
      else if (ch) { g.textContent = 'Challenge done — now decide which number is honest.'; g.style.color = '#f5d76e'; }
      else if (!L1.gzPred) { g.textContent = 'Start with your prediction.'; g.style.color = '#f5d76e'; } }
    gzPredRender(); }; }

// ---------- FIRE MOUNTAIN: no giveaway notes, evidence via history + backup gauge ----------
const gzFMrev = new Set();
{ const _fmg = fmGen; fmGen = function (seed) {
    const d = _fmg(seed), r = DDMath.rng(seed * 11 + 3);
    ['A', 'B'].forEach(k => d[k].forEach(s => {
      s.note = 'No worker note on this one. Use the evidence: the history chart and the backup gauge.';
      if (s.odd) s.backup = k === 'A' ? 70 + Math.round(r() * 10) : s.val - Math.round(1 + r() * 5);
      else s.backup = s.val + Math.round((r() - .5) * 4);
    }));
    gzFMrev.clear(); return d; }; }
{ const _fr = fmRender; fmRender = function () {
    _fr();
    const k = FM.which, s = FM[k][FM.sel], btn = $d('fm-rem'); if (!btn) return;
    const box = btn.closest('.ancient-carving-box'), key = k + '-' + FM.sel;
    const row = btn.closest('.l1-row');
    row.insertAdjacentHTML('beforebegin', '<div class="gz-panel" style="margin:4px 0">' + (gzFMrev.has(key)
      ? '🔧 Backup gauge beside sensor ' + s.id + ' reads <b>' + s.backup + '°C</b>' + (Math.abs(s.backup - s.val) > 25 ? ' <span class="gz-warn">— very different from the sensor!</span>' : ' <span class="gz-good">— agrees with the sensor.</span>')
      : '<button class="runic-btn" id="gz-backup">CHECK BACKUP GAUGE</button> <small style="color:#9ba3b5">A second gauge sits next to every sensor.</small>') + '</div>');
    const b = $d('gz-backup'); if (b) b.onclick = () => { gzFMrev.add(key); soundFX.playMechanismClick(); fmRender(); };
    const cap = box.querySelector('small'); if (cap) cap.textContent = 'Last 5 readings (oldest → newest). Sudden jump, or step-by-step climb?';
  }; }
{ const _run = fmRun; fmRun = function () { const k = FM.which; _run(); if (FM.res[k] && !FM.res[k].good) gzLoseHeart(k === 'A' ? 'Cooling ran for no reason.' : 'The furnace overheated.'); }; }
openEmberLog = function (which) {
  const r1 = gameState.regions[1]; soundFX.playMechanismClick();
  if (which === 'A') r1.lensLogInspected = true; else r1.seismoLogInspected = true; saveGameState();
  openAncientModal(which === 'A' ? 'Temperature Report 1 — Furnace 1' : 'Temperature Report 2 — Furnace 2', '<div class="ancient-carving-box"><div class="carving-subtitle">Worker’s log</div><p style="font-style:italic;line-height:1.6;color:var(--parchment)">' + (which === 'A'
    ? '“One of the nine sensors in Furnace 1 is showing something wild. I didn’t have time to check which. Boss says: a <b>broken</b> sensor usually <b>jumps suddenly</b>, and the backup gauge next to it <b>disagrees</b>. Check before you delete anything.”'
    : '“Furnace 2 has a reading way above the rest too. Could be real this time. <b>Real</b> heat <b>climbs step by step</b>, and the backup gauge <b>agrees</b>. If it’s real and you remove it, the cooling won’t start.”') + '</p></div>');
};

// ---------- STAR PATH: rate the headline ----------
{ const _sl = spLoad; spLoad = function (k) { _sl(k); SP.gzVerdict = null; }; }
{ const _si = spInfo; spInfo = function () {
    _si();
    const info = $d('sp-info'); if (!info) return;
    if (SP.set === 'ice' && SP.weatherOK) {
      info.insertAdjacentHTML('beforeend', '<div class="gz-panel"><b>📰 Rate the headline:</b> "Buying ice cream makes people go swimming!"' + (SP.gzVerdict === 'conf'
        ? '<div class="gz-good">✔ Confounded. They really are linked, but hot weather drives both.</div>'
        : '<div class="gz-choice"><button class="runic-btn" data-hv="cause">TRUE — ice cream causes it</button><button class="runic-btn" data-hv="none">FALSE — there is no link</button><button class="runic-btn" data-hv="conf">CONFOUNDED — something else drives both</button></div><div id="gz-hmsg"></div>') + '</div>');
      info.querySelectorAll('[data-hv]').forEach(b => b.onclick = () => {
        if (b.dataset.hv === 'conf') { SP.gzVerdict = 'conf'; soundFX.playCollect(); spInfo(); }
        else { gzLoseHeart(b.dataset.hv === 'cause' ? 'Linked ≠ caused.' : 'There IS a strong link (high r).'); const m = $d('gz-hmsg'); if (m) m.innerHTML = '<span class="gz-bad">' + (b.dataset.hv === 'cause' ? '✖ On days with similar weather the link almost vanishes. Ice cream isn\'t pushing anyone into the pool.' : '✖ Overall r is high, so there is a link. The question is what causes it.') + '</span>'; }
      });
    }
    const chk = $d('sp-check');
    if (chk) chk.insertAdjacentHTML('beforeend', '<div>' + (SP.gzVerdict === 'conf' ? '✔' : '○') + ' Rate the headline</div>');
    SP.ready = !!SP.ready && SP.gzVerdict === 'conf';
    const bb = $d('sp-build'); if (bb) { bb.disabled = !SP.ready; bb.style.opacity = SP.ready ? 1 : .45; }
  }; }

// ---------- MAGIC FOREST: random seeded creatures + elbow decision ----------
function gzKm(pts, k, r, runs) {
  let best = Infinity, bestC = null;
  for (let t = 0; t < (runs || 10); t++) {
    let c = []; const used = new Set();
    while (c.length < k) { const i = Math.floor(r() * pts.length); if (!used.has(i)) { used.add(i); c.push({ x: pts[i].x, y: pts[i].y }); } }
    for (let it = 0; it < 40; it++) { const a = AM.kMeansAssign(pts, c); c = AM.kMeansUpdateCentroids(a, c); }
    const w = AM.kMeansWCSS(AM.kMeansAssign(pts, c), c); if (w < best) { best = w; bestC = c; }
  }
  return { w: best, c: bestC };
}
function gzForestGen(seed) {
  const sets = [['Moss-Wisp', 'Dew-Stag', 'Gloam-Moth'], ['Ember-Fox', 'Fog-Owl', 'Rain-Toad'], ['Glow-Bug', 'Root-Rabbit', 'Mist-Deer']];
  for (let t = 0; t < 300; t++) {
    const r = DDMath.rng(seed * 13 + t), u = (a, b) => a + (b - a) * r();
    const C = []; let tries = 0;
    while (C.length < 3 && tries < 200) { tries++; const c = { x: u(80, 580), y: u(55, 185) }; if (C.every(d => Math.hypot(d.x - c.x, d.y - c.y) > 170)) C.push(c); }
    if (C.length < 3) continue;
    const names = sets[Math.floor(r() * sets.length)], pts = []; let id = 1;
    C.forEach((c, ci) => { const n = 5 + Math.floor(r() * 3), sp = 20 + r() * 10; for (let i = 0; i < n; i++) pts.push({ id: id++, x: clamp(c.x + gauss(r) * sp * .6, 15, 645), y: clamp(c.y + gauss(r) * sp * .6, 15, 225), species: names[ci] }); });
    const W = [2, 3, 4].map(k => gzKm(pts, k, r, 8).w);
    if (W[0] - W[1] > 3 * (W[1] - W[2])) return pts;
  }
  return REALMS[3].creatures;
}
function gzForestNew() {
  REALMS[3].creatures = gzForestGen(ddSeed('forest'));
  const r3 = gameState.regions[3]; r3.tried = {}; r3.kValue = 2; r3.centroids = null; r3.iterationsRun = 0;
}
addEventListener('click', e => {
  const b = e.target.closest && e.target.closest('#btn-wilds-open-path'); if (!b) return;
  e.stopImmediatePropagation(); e.preventDefault(); gzForestDecide();
}, true);
function gzForestDecide() {
  const r3 = gameState.regions[3], tried = r3.tried || {}, miss = [2, 3, 4].filter(k => tried[k] == null);
  const msg = $d('wilds-status-msg');
  if (miss.length) { if (msg) { msg.style.color = '#fcd34d'; msg.textContent = 'Run K-means until the centres stop moving for 2, 3 AND 4 groups first. Still to do: ' + miss.join(', ') + ' groups.'; } gzPulse(msg); return; }
  const pts = REALMS[3].creatures, r = DDMath.rng(77), best = [2, 3, 4].map(k => gzKm(pts, k, r, 12).w);
  openAncientModal('Forest Map — how many groups?', '<div class="ancient-carving-box"><div class="carving-subtitle">The elbow chart</div><p style="font-size:.88rem;line-height:1.5">WCSS = how spread out the groups are (smaller = tighter). Adding groups always makes WCSS smaller, so "smallest WCSS" is not the answer. Look for the <b>elbow</b>: the point after which one more group barely helps.</p></div><canvas id="gz-elbow"></canvas><p style="font-size:.8rem;color:#9ba3b5">Line: best of 12 K-means runs for each k. Dots: your own runs.</p><div class="gz-panel"><b>How many groups fit these creatures best?</b><div class="gz-choice"><button class="runic-btn" data-ek="2">2 groups</button><button class="runic-btn" data-ek="3">3 groups</button><button class="runic-btn" data-ek="4">4 groups</button><button class="runic-btn" id="gz-eback">◀ back to the map</button></div><div id="gz-emsg"></div></div>');
  const c = ddCvs('gz-elbow', 520, 240), g = c.getContext('2d'), mx = Math.max(...best, ...[2, 3, 4].map(k => tried[k])) * 1.1;
  const X = k => 70 + (k - 2) * 190, Y = w => 205 - w / mx * 175;
  g.strokeStyle = 'rgba(255,255,255,.12)'; for (let i = 0; i <= 4; i++) { g.beginPath(); g.moveTo(50, Y(mx * i / 4)); g.lineTo(500, Y(mx * i / 4)); g.stroke(); }
  g.strokeStyle = '#f5d76e'; g.lineWidth = 3; g.beginPath(); [2, 3, 4].forEach((k, i) => { i ? g.lineTo(X(k), Y(best[i])) : g.moveTo(X(k), Y(best[i])); }); g.stroke();
  g.font = '12px sans-serif'; g.textAlign = 'center';
  [2, 3, 4].forEach((k, i) => { g.fillStyle = '#f5d76e'; g.beginPath(); g.arc(X(k), Y(best[i]), 6, 0, 6.28); g.fill(); g.fillStyle = '#2dd4bf'; g.beginPath(); g.arc(X(k) + 14, Y(tried[k]), 4, 0, 6.28); g.fill();
    g.fillStyle = '#e2d9c5'; g.fillText(k + ' groups', X(k), 228); g.fillText(Math.round(best[i]).toLocaleString(), X(k), Y(best[i]) - 12); });
  g.fillStyle = '#fca5a5'; g.fillText('−' + Math.round(best[0] - best[1]).toLocaleString(), (X(2) + X(3)) / 2, (Y(best[0]) + Y(best[1])) / 2 - 10);
  g.fillText('−' + Math.round(best[1] - best[2]).toLocaleString(), (X(3) + X(4)) / 2, (Y(best[1]) + Y(best[2])) / 2 - 10);
  $d('gz-eback').onclick = () => openWildsMechanism();
  document.querySelectorAll('[data-ek]').forEach(b => b.onclick = () => {
    const k = +b.dataset.ek, m = $d('gz-emsg');
    if (k === 3) { soundFX.playCollect(); unlockCodex('wilds_kmeans'); completeRegion(3); closeAncientModal(); setAriaSpeech('3 groups. big drop to 3, tiny drop after. that\'s the elbow. the forest is happy.'); }
    else { gzLoseHeart(k === 2 ? 'Too few groups.' : 'Too many groups.'); if (m) m.innerHTML = '<span class="gz-bad">' + (k === 2 ? '✖ Going from 2 to 3 groups still cuts WCSS a lot, so two different kinds of creature are squashed into one group.' : '✖ The 4th group only shaves a little off WCSS. It just splits a real group in half.') + '</span>'; }
  });
}

// ---------- DARK CASTLE: 3-phase boss (regression, overfitting, extrapolation) ----------
const gzCA = { train: [], w: [], far: null, phase: 0, marker: null, hw: 6, anim: null, done: null, msg: '', good: null, res: [], lineHint: false, show: false, curveChoice: null };
function gzLag(pts, x) { let s = 0; for (let i = 0; i < pts.length; i++) { let L = 1; for (let j = 0; j < pts.length; j++) if (j !== i) L *= (x - pts[j].x) / (pts[i].x - pts[j].x); s += L * pts[i].y; } return s; }
function gzCaGen(seed) {
  for (let t = 0; t < 800; t++) {
    const r = DDMath.rng(seed * 5 + t), m = 4 + r() * 3, b = 8 + r() * 8, ln = x => b + m * x, nz = () => gauss(r) * 1.1;
    const train = [1, 2, 3, 4, 5, 6].map(x => ({ x, y: +(ln(x) + nz()).toFixed(1) }));
    const w = [7, 8, 9].map(x => ({ x, y: +(ln(x) + nz()).toFixed(1) }));
    const bend = 10 + r() * 5, far = { x: 16, y: +(ln(16) - bend + nz()).toFixed(1) };
    const f = AM.linearRegressionOLS(train), L = x => f.slope * x + f.intercept;
    if (!w.every(q => Math.abs(L(q.x) - q.y) <= 3.5)) continue;
    if (Math.abs(gzLag(train, 9) - w[2].y) < 14) continue;
    const fe = Math.abs(L(16) - far.y); if (fe < 8 || fe > 17) continue;
    return { train, w, far };
  }
  return { train: [{ x: 1, y: 18 }, { x: 2, y: 25.5 }, { x: 3, y: 31 }, { x: 4, y: 38.5 }, { x: 5, y: 44 }, { x: 6, y: 51.5 }], w: [{ x: 7, y: 57.5 }, { x: 8, y: 64 }, { x: 9, y: 70.5 }], far: { x: 16, y: 104 } };
}
function gzCaNew(force) { const d = gzCaGen(force || ddSeed('castle')); Object.assign(gzCA, d, { phase: 0, marker: null, hw: 6, anim: null, done: null, msg: '', good: null, res: [], lineHint: false, show: false, curveChoice: null }); }
function gzCaFit() { const f = AM.linearRegressionOLS(gzCA.train); return { m: f.slope, b: f.intercept, L: x => f.slope * x + f.intercept }; }
function gzCaTarget() { return gzCA.phase < 3 ? gzCA.w[gzCA.phase] : gzCA.far; }
inspectThroneTablet = function (idx) {
  if (!gzCA.train.length) gzCaNew();
  const r4 = gameState.regions[4]; r4.tabletsInspected[idx] = true; soundFX.playMechanismClick(); saveGameState();
  const p = gzCA.train.slice(2 * idx, 2 * idx + 2);
  openAncientModal('Old Tablet ' + (idx + 1) + ' — Attacks ' + (2 * idx + 1) + ' and ' + (2 * idx + 2), '<div class="ancient-carving-box"><div class="carving-subtitle">Past attacks</div><p style="font-style:italic;line-height:1.6;color:var(--parchment)">' + p.map(q => 'Attack ' + q.x + ': the monster struck position <strong>' + q.y + '</strong>.').join(' ') + ' Spot the pattern?</p></div>');
};
function gzCaScale() {
  const F = gzCaFit(), xMax = gzCA.phase >= 3 ? 17 : 10;
  const ys = [...gzCA.train.map(p => p.y), ...gzCA.w.map(p => p.y), F.L(xMax), 100]; if (gzCA.phase >= 3) ys.push(gzCA.far.y + 25);
  const yMax = Math.max(...ys) + 8;
  return { F, xMax, yMax, X: x => 40 + x / xMax * 470, Y: y => 270 - y / yMax * 240 };
}
function gzCaDraw() {
  const c = $d('gz-ca-cv'); if (!c) return; const g = c.getContext('2d'), S = gzCaScale(), now = performance.now(), T = gzCaTarget();
  g.clearRect(0, 0, 560, 300);
  g.save();
  if (gzCA.shake > 0 && !gzRM()) { g.translate((Math.random() - .5) * gzCA.shake, (Math.random() - .5) * gzCA.shake); gzCA.shake *= .85; if (gzCA.shake < .5) gzCA.shake = 0; }
  const bg = g.createLinearGradient(0, 0, 0, 300); bg.addColorStop(0, '#120a24'); bg.addColorStop(1, '#0a1020'); g.fillStyle = bg; g.fillRect(0, 0, 560, 300);
  g.strokeStyle = 'rgba(255,255,255,.08)'; g.lineWidth = 1;
  for (let i = 0; i <= S.xMax; i++) { g.beginPath(); g.moveTo(S.X(i), 30); g.lineTo(S.X(i), 270); g.stroke(); }
  g.fillStyle = '#9ba3b5'; g.font = '11px sans-serif'; g.textAlign = 'center';
  for (let i = 1; i <= S.xMax; i++) if (S.xMax <= 10 || i % 2 === 0 || i === 16) g.fillText(i, S.X(i), 285);
  g.fillText('night →', 290, 298);
  g.fillStyle = 'rgba(45,212,191,.06)'; g.fillRect(S.X(.5), 30, S.X(6.5) - S.X(.5), 240);
  g.fillStyle = '#2dd4bf'; g.textAlign = 'left'; g.fillText('data we have', S.X(.6), 44);
  // column for current target
  if (T && gzCA.phase < 4) { const pul = .08 + .05 * Math.sin(now / 250); g.fillStyle = 'rgba(245,215,110,' + pul + ')'; g.fillRect(S.X(T.x) - 13, 30, 26, 240); }
  // line
  if (gzCA.show || gzCA.phase >= 2) { g.strokeStyle = '#f5d76e'; g.lineWidth = 2.5; g.beginPath(); g.moveTo(S.X(0), S.Y(S.F.L(0))); g.lineTo(S.X(S.xMax), S.Y(S.F.L(S.xMax))); g.stroke(); }
  // overfit curve in phase 2
  if (gzCA.phase === 2) { g.save(); g.beginPath(); g.rect(0, 30, 560, 240); g.clip(); g.strokeStyle = '#f472b6'; g.lineWidth = 2.5; g.setLineDash([6, 4]); g.beginPath(); for (let x = .6; x <= 9.6; x += .05) { const y = gzLag(gzCA.train, x); x < .65 ? g.moveTo(S.X(x), S.Y(y)) : g.lineTo(S.X(x), S.Y(y)); } g.stroke(); g.setLineDash([]); g.restore(); }
  // uncertainty fan after the far attack
  if (gzCA.phase === 3 && gzCA.done) { g.fillStyle = 'rgba(168,85,247,.16)'; g.beginPath(); for (let x = 1; x <= 17; x += .5) g.lineTo(S.X(x), S.Y(S.F.L(x) + 2 + Math.pow(Math.abs(x - 3.5), 1.35) * .9)); for (let x = 17; x >= 1; x -= .5) g.lineTo(S.X(x), S.Y(S.F.L(x) - 2 - Math.pow(Math.abs(x - 3.5), 1.35) * .9)); g.closePath(); g.fill(); g.fillStyle = '#c084fc'; g.fillText('uncertainty grows with distance', S.X(10), S.Y(S.F.L(10)) - 30); }
  // training points
  gzCA.train.forEach(p => { g.fillStyle = '#2dd4bf'; g.shadowColor = '#2dd4bf'; g.shadowBlur = 8; g.beginPath(); g.arc(S.X(p.x), S.Y(p.y), 5.5, 0, 6.28); g.fill(); g.shadowBlur = 0; });
  // past results
  gzCA.res.forEach(q => { g.fillStyle = q.good ? '#10b981' : '#ef4444'; g.beginPath(); g.arc(S.X(q.x), S.Y(q.y), 6, 0, 6.28); g.fill(); g.fillStyle = '#fff'; g.font = 'bold 10px sans-serif'; g.textAlign = 'center'; g.fillText(q.good ? '✓' : '✕', S.X(q.x), S.Y(q.y) + 3.5); });
  // shield
  if (gzCA.marker != null && T) {
    const sx = S.X(T.x), top = S.Y(gzCA.marker + gzCA.hw), bot = S.Y(gzCA.marker - gzCA.hw);
    const sg = g.createLinearGradient(sx - 16, 0, sx + 16, 0); sg.addColorStop(0, 'rgba(56,189,248,.05)'); sg.addColorStop(.5, 'rgba(56,189,248,.35)'); sg.addColorStop(1, 'rgba(56,189,248,.05)');
    g.fillStyle = sg; g.fillRect(sx - 16, Math.max(30, top), 32, Math.min(270, bot) - Math.max(30, top));
    g.strokeStyle = '#38bdf8'; g.lineWidth = 3; g.beginPath(); g.moveTo(sx - 16, S.Y(gzCA.marker)); g.lineTo(sx + 16, S.Y(gzCA.marker)); g.stroke();
    g.fillStyle = '#38bdf8'; g.font = '11px sans-serif'; g.textAlign = 'center'; g.fillText('search ±' + gzCA.hw, sx, Math.max(40, top - 6));
  }
  // the Stranger: hooded silhouette in a long coat, watching
  const mx = 515, my = 70 + Math.sin(now / 900) * 2, tgt = gzCA.anim ? gzCA.anim : (T ? { x: S.X(T.x), y: 150 } : { x: 300, y: 150 });
  g.save(); g.translate(mx, my);
  const mg = g.createRadialGradient(0, 10, 4, 0, 10, 60); mg.addColorStop(0, 'rgba(225,29,72,.22)'); mg.addColorStop(1, 'rgba(225,29,72,0)'); g.fillStyle = mg; g.beginPath(); g.arc(0, 10, 60, 0, 6.28); g.fill();
  g.fillStyle = '#05050a'; g.strokeStyle = gzHP.h > 0 && gzCA.phase < 4 ? 'rgba(225,29,72,.8)' : 'rgba(45,212,191,.8)'; g.lineWidth = 1.5;
  g.beginPath(); g.moveTo(-9, -30); g.quadraticCurveTo(0, -46, 10, -30); g.lineTo(12, -16); g.lineTo(20, 40); g.lineTo(-18, 40); g.lineTo(-11, -16); g.closePath(); g.fill(); g.stroke();
  const flick = Math.random() < .04 ? 0 : 1, ea = Math.atan2(tgt.y - my, tgt.x - mx);
  g.fillStyle = 'rgba(255,80,90,' + (0.85 * flick) + ')'; g.beginPath(); g.arc(Math.cos(ea) * 2 - 2, -26, 1.2, 0, 6.28); g.arc(Math.cos(ea) * 2 + 3, -26, 1.2, 0, 6.28); g.fill();
  g.restore();
  // projectile
  if (gzCA.anim) { const a = gzCA.anim; for (let i = 0; i < 8; i++) { const k = i / 8, tx = a.x + (mx - a.x) * k * .25 * (1 - a.k), ty = a.y + (my - a.y) * k * .25 * (1 - a.k); g.fillStyle = 'rgba(244,63,94,' + (.7 - k * .7) + ')'; g.beginPath(); g.arc(tx, ty, 8 - k * 6, 0, 6.28); g.fill(); } g.fillStyle = '#fff'; g.beginPath(); g.arc(a.x, a.y, 5, 0, 6.28); g.fill(); }
  // impact ring
  if (gzCA.impact) { const im = gzCA.impact, k = (now - im.t) / 500; if (k < 1) { g.strokeStyle = im.good ? 'rgba(56,189,248,' + (1 - k) + ')' : 'rgba(239,68,68,' + (1 - k) + ')'; g.lineWidth = 4; g.beginPath(); g.arc(im.x, im.y, 10 + k * 40, 0, 6.28); g.stroke(); } else gzCA.impact = null; }
  g.restore();
}
function gzCaLoop() { if (!$d('gz-ca-cv') || !$d('ancient-modal').classList.contains('active')) { gzCA.loop = false; return; } gzCaDraw(); requestAnimationFrame(gzCaLoop); }
function gzCaUI() {
  const P = gzCA.phase, T = gzCaTarget(), F = gzCaFit(), el = $d('gz-ca-ui'); if (!el) return;
  const trainErr = Math.sqrt(AM.mean(gzCA.train.map(p => Math.pow(p.y - F.L(p.x), 2))));
  let h = '<div class="carving-subtitle">' + (P < 2 ? 'PHASE 1 — Attack ' + (P + 1) + ' of 2' : P === 2 ? 'PHASE 2 — The boss offers a deal' : P === 3 ? 'PHASE 3 — The far attack' : 'BOSS DEFEATED') + '</div>';
  if (P < 2) {
    h += '<p>The boss will strike at <b>attack ' + T.x + '</b>. Click the glowing column to place your shield (or use ▲ ▼), then COMMIT. Shield covers ±6.</p>' + (gzCA.show ? '<p style="color:#f5d76e">Best-fit line: position = ' + fmt(F.b, 1) + ' + ' + fmt(F.m, 2) + ' × attack. At attack ' + T.x + ' it says <b>' + fmt(F.L(T.x), 1) + '</b>.</p>' : '<p style="color:#9ba3b5">Line hidden. Try reading the pattern yourself first.</p>');
    if (!gzCA.done) h += '<div class="gz-choice"><button class="runic-btn" id="gz-up">▲</button><button class="runic-btn" id="gz-dn">▼</button><button class="hero-btn primary" id="gz-commit" style="padding:8px 18px">COMMIT' + (gzCA.marker != null ? ' at ' + fmt(gzCA.marker, 1) : '') + '</button>' + (gzCA.show ? '' : '<button class="runic-btn" id="gz-line">SHOW BEST-FIT LINE (uses a hint)</button>') + '</div>';
  } else if (P === 2) {
    const cp = gzLag(gzCA.train, 9);
    h += '<p>"Your boring line misses my old attacks," the boss laughs. "My <span style="color:#f472b6">pink curve</span> passes through <b>every single one</b>. Use it for attack 9."</p><table style="width:100%;font-size:.85rem;text-align:center"><tr><th></th><th>Error on old attacks</th><th>Says attack 9 lands at</th></tr><tr><td style="color:#f5d76e">Straight line</td><td>' + fmt(trainErr, 2) + '</td><td>' + fmt(F.L(9), 1) + '</td></tr><tr><td style="color:#f472b6">Perfect curve</td><td>0.00</td><td>' + fmt(cp, 1) + '</td></tr></table>';
    if (!gzCA.done) h += '<div class="gz-choice"><button class="hero-btn primary" id="gz-useline" style="padding:8px 16px">TRUST THE STRAIGHT LINE</button><button class="hero-btn" id="gz-usecurve" style="padding:8px 16px;border-color:#f472b6;color:#f9a8d4">TRUST THE PERFECT CURVE</button></div>';
  } else if (P === 3) {
    h += '<p>Attack <b>16</b> is way beyond anything we\'ve seen (attacks 1–6). The line says <b>' + fmt(F.L(16), 1) + '</b>. How sure can you be this far out?</p>';
    if (!gzCA.done) h += '<div class="gz-choice"><button class="hero-btn primary" id="gz-narrow" style="padding:8px 16px">NARROW SHIELD (±6) on the line</button><button class="hero-btn primary" id="gz-wide" style="padding:8px 16px">WIDE SHIELD (±20) on the line</button></div>';
  }
  if (gzCA.msg) h += '<p class="' + (gzCA.good ? 'gz-good' : 'gz-bad') + '">' + gzCA.msg + '</p>';
  if (gzCA.done && gzIsLive()) h += '<div class="gz-choice"><button class="hero-btn primary" id="gz-next" style="padding:8px 18px">' + (P >= 3 ? 'FINISH THE BOSS' : 'NEXT ▶') + '</button></div>';
  h += '<small style="color:#9ba3b5">A prediction is an estimate, not a promise.</small>';
  el.innerHTML = h;
  const on = (id, f) => { const b = $d(id); if (b) b.onclick = f; };
  on('gz-up', () => { gzCA.marker = clamp((gzCA.marker == null ? 50 : gzCA.marker) + 1, 0, 200); gzCaUI(); });
  on('gz-dn', () => { gzCA.marker = clamp((gzCA.marker == null ? 50 : gzCA.marker) - 1, 0, 200); gzCaUI(); });
  on('gz-line', () => { gzCA.show = true; if (!gzCA.lineHint) { gzCA.lineHint = true; ddHintCount++; } gzCaUI(); });
  on('gz-commit', () => { if (gzCA.marker == null) { gzCA.msg = 'Place your shield first: click the glowing column.'; gzCA.good = false; gzCaUI(); return; } gzCaFire(); });
  on('gz-useline', () => { gzCA.curveChoice = 'line'; gzCA.marker = F.L(9); gzCaFire(); });
  on('gz-usecurve', () => { gzCA.curveChoice = 'curve'; gzCA.marker = gzLag(gzCA.train, 9); gzCaFire(); });
  on('gz-narrow', () => { gzCA.hw = 6; gzCA.marker = F.L(16); gzCaFire(); });
  on('gz-wide', () => { gzCA.hw = 20; gzCA.marker = F.L(16); gzCaFire(); });
  on('gz-next', () => {
    if (gzCA.phase >= 3) { unlockCodex('throne_regression'); completeRegion(4); setTimeout(() => setAriaSpeech('boss down. you predicted the future and didn\'t get tricked by a "perfect" model.'), 100); return; }
    gzCA.phase++; gzCA.marker = null; gzCA.done = null; gzCA.msg = ''; gzCA.hw = 6; gzCaUI();
  });
}
function gzCaFire() {
  if (gzCA.anim || gzCA.done) return;
  const T = gzCaTarget(), S = gzCaScale(), sx = S.X(T.x), t0 = performance.now(), from = { x: 515, y: 70 }, to = { x: sx, y: S.Y(T.y) };
  soundFX.playGuardianPulse();
  const step = now => {
    const k = Math.min(1, (now - t0) / 750), e = k * k * (3 - 2 * k);
    gzCA.anim = { x: from.x + (to.x - from.x) * e, y: from.y + (to.y - from.y) * e - Math.sin(k * Math.PI) * 50, k };
    if (k < 1) return requestAnimationFrame(step);
    gzCA.anim = null;
    const err = Math.abs(gzCA.marker - T.y), good = err <= gzCA.hw, F = gzCaFit();
    gzCA.good = good; gzCA.done = true; gzCA.res.push({ x: T.x, y: T.y, good });
    gzCA.impact = { x: to.x, y: to.y, t: performance.now(), good }; gzCA.shake = good ? 4 : 14;
    if (gzCA.phase < 2) gzCA.msg = (good ? '✔ Blocked! ' : '✖ Hit! ') + 'It struck ' + fmt(T.y, 1) + '. You were off by ' + fmt(err, 1) + '. The line would have been off by ' + fmt(Math.abs(F.L(T.x) - T.y), 1) + '.';
    else if (gzCA.phase === 2) { unlockCodex('throne_overfit'); gzCA.msg = gzCA.curveChoice === 'line' ? '✔ Blocked! It struck ' + fmt(T.y, 1) + '. The "perfect" curve would have been off by ' + fmt(Math.abs(gzLag(gzCA.train, 9) - T.y), 1) + '. Zero error on old data ≠ good predictions. That curve was OVERFITTING: it learned the noise.' : '✖ Hit! It struck ' + fmt(T.y, 1) + ', the curve said ' + fmt(gzLag(gzCA.train, 9), 1) + '. The curve memorised the noise in the old attacks. Zero training error, terrible prediction — that\'s OVERFITTING.'; }
    else gzCA.msg = (good ? '✔ Blocked with the wide shield. ' : '✖ Hit! ') + 'It struck ' + fmt(T.y, 1) + ', the line said ' + fmt(F.L(16), 1) + ' (off by ' + fmt(Math.abs(F.L(16) - T.y), 1) + '). The boss got tired and the pattern bent. Far from your data, patterns can change, so plan for a bigger error.';
    if (good) { soundFX.playCollect(); ddSay('cheer', 'ari', true); } else { gzLoseHeart(gzCA.phase === 2 ? 'The perfect curve failed.' : 'He slipped away.'); if (gzIsLive()) { gzCA.res.pop(); gzCA.done = null; gzCA.marker = null; gzCA.msg = '◀◀ REWOUND. You remember what happened: ' + gzCA.msg + ' Try again.'; } }
    gzCaUI();
  };
  requestAnimationFrame(step);
}
openThroneMechanism = function () {
  if (!gzCA.train.length) gzCaNew();
  openAncientModal('Dark Castle — Boss Fight', '<div class="ancient-carving-box" style="margin-bottom:4px"><p style="font-size:.86rem;line-height:1.5;margin:0">Teal dots = where the boss struck in attacks 1–6. Read the pattern and survive 3 phases. Every hit costs a heart.</p></div><canvas id="gz-ca-cv"></canvas><div id="gz-ca-ui" class="ancient-carving-box"></div>' + ddSeedBox('castle'));
  const c = ddCvs('gz-ca-cv', 560, 300);
  c.onpointerdown = e => { if (gzCA.phase >= 2 || gzCA.done || gzCA.anim) return; const b = c.getBoundingClientRect(), py = (e.clientY - b.top) / b.height * 300, S = gzCaScale(); gzCA.marker = clamp((270 - py) / 240 * S.yMax, 0, S.yMax); soundFX.playMechanismClick(); gzCaUI(); };
  $d('castle-seedgo').onclick = () => { const v = parseInt($d('castle-seedin').value); if (v > 0) { ddSeed('castle', v); gzCaNew(v); openThroneMechanism(); } };
  $d('castle-newdata').onclick = () => { gzCaNew(ddSeed('castle')); openThroneMechanism(); };
  gzCaUI(); gzHpRender();
  if (!gzCA.loop) { gzCA.loop = true; requestAnimationFrame(gzCaLoop); }
};
{ const _o = openAncientModal; openAncientModal = function (t, h) { _o(t, h); gzHpRender(); }; }

// ---------- quizzes: different post-game questions, 6 objectives ----------
const gzQ = {
  pre: [['Which is changed MOST by one very large number added to the data?', ['Mean', 'Median', 'Mode'], 0], ['A sensor shows 245°C while the others show about 75°C. What should you do first?', ['Delete it straight away', 'Check if the sensor is broken or the reading is real', 'Ignore all the other data'], 1], ['Ice cream sales and swimming both rise on hot days. What does this show?', ['Ice cream causes swimming', 'They may both be caused by hot weather', 'The data must be wrong'], 1], ['In K-means, after every point joins its nearest centre, what happens next?', ['Each centre moves to the mean position of its group', 'The points are deleted', 'The number of groups changes randomly'], 0], ['What is a regression line fitted to past data used for?', ['To predict a new value', 'To sort the data', 'To delete outliers'], 0], ['A model fits its past data perfectly but predicts new data badly. What is this called?', ['Overfitting', 'Correlation', 'Clustering'], 0]],
  post: [['Café pay: 20, 22, 23, 25, 400 (the owner). Which number best shows what a typical worker earns?', ['Mean', 'Median', 'Range'], 1], ['A speed camera says a bicycle went 190 km/h. What should you do before removing it?', ['Remove it, it is clearly an outlier', 'Check whether the camera glitched or the reading is real', 'Change the other readings to match'], 1], ['Cities with more firefighters at a fire have more fire damage. What is most likely?', ['Firefighters cause the damage', 'Bigger fires bring more firefighters AND more damage', 'There is no correlation'], 1], ['WCSS falls a lot from 2 to 3 groups but only a little from 3 to 4. How many groups fit best?', ['2', '3', '4'], 1], ['A line was fitted to data for x = 1 to 10. Where is its prediction least reliable?', ['x = 5', 'x = 9', 'x = 40'], 2], ['Model A: error 0 on training data, 25 on new data. Model B: 3 on training, 4 on new. Which should you trust?', ['Model A', 'Model B', 'Both equally'], 1]]
};
ddQuiz = function (kind, done) {
  const Q = gzQ[kind];
  const h = '<h2>' + (kind === 'pre' ? 'Quick pre-game quiz' : 'Post-game quiz') + '</h2><p style="text-align:center;font-size:.85rem">' + Q.length + ' questions. ' + (kind === 'pre' ? 'It is OK if you do not know yet!' : 'New situations, same ideas.') + '</p>' + Q.map((q, i) => '<h3>' + (i + 1) + '. ' + q[0] + '</h3>' + q[1].map((o, j) => '<label style="display:block;cursor:pointer"><input type="radio" name="q' + i + '" value="' + j + '"> ' + o + '</label>').join('')).join('') + '<div class="dd-row"><button class="dd-btn" id="dd-q-skip">' + (kind === 'pre' ? 'SKIP' : 'CANCEL') + '</button><button class="dd-btn main" id="dd-q-go">SUBMIT</button></div>';
  const o = ddOverlay('dd-quiz', h);
  $d('dd-q-skip').onclick = () => { o.classList.remove('on'); done && done(); };
  $d('dd-q-go').onclick = () => {
    const ans = Q.map((q, i) => { const c = o.querySelector('input[name=q' + i + ']:checked'); return c ? +c.value : -1; }), sc = ans.filter((a, i) => a === Q[i][2]).length;
    const r = ddR(); r[kind] = { score: sc, total: Q.length, answers: ans, time: new Date().toISOString() }; ddRS(r);
    o.querySelector('.dd-card').innerHTML = '<h2>Score: ' + sc + ' / ' + Q.length + '</h2><p style="text-align:center">Saved. ' + (kind === 'pre' ? 'Now go and play!' : 'Thank you!') + '</p><div class="dd-row"><button class="dd-btn main" id="dd-q-ok">OK</button></div>'; $d('dd-q-ok').onclick = () => { o.classList.remove('on'); done && done(); };
  };
};
// exports: try a normal download, and always show the text so it can be copied (downloads are blocked in some viewers)
ddDownload = function (name, text, type) {
  try { const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([text], { type })); a.download = name; document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 500); } catch (e) {}
  const o = ddOverlay('gz-export', '<h2>Export: ' + name + '</h2><p style="text-align:center;font-size:.85rem">If the download didn\'t start, copy the text below and save it as <b>' + name + '</b>.</p><textarea id="gz-ex-t" readonly style="width:100%;height:220px;background:#0a1020;color:#e2d9c5;border:1px solid #d4af37;border-radius:8px;font-family:monospace;font-size:.75rem"></textarea><div class="dd-row"><button class="dd-btn main" id="gz-ex-copy">COPY</button><button class="dd-btn" id="gz-ex-x">CLOSE</button></div>');
  $d('gz-ex-t').value = text;
  $d('gz-ex-copy').onclick = () => { const t = $d('gz-ex-t'); t.select(); (navigator.clipboard ? navigator.clipboard.writeText(text) : Promise.reject()).then(() => showToast('Copied!'), () => { try { document.execCommand('copy'); showToast('Copied!'); } catch (e) { showToast('Select the text and copy it.'); } }); };
  $d('gz-ex-x').onclick = () => o.classList.remove('on');
};
ddHub = function () {
  const r = ddR(), sc = q => q ? q.score + '/' + (q.total || 5) : 'not taken';
  const rows = [0, 1, 2, 3, 4].map(i => { const l = r.levels[i] || {}; return '<tr><td>' + (i + 1) + '</td><td>' + (l.completed ? 'yes' : 'no') + '</td><td>' + (l.attempts || 0) + '</td><td>' + (l.hints || 0) + '</td><td>' + (l.seconds || '-') + '</td></tr>'; }).join('');
  const o = ddOverlay('dd-hub', '<h2>Playtest</h2><p style="text-align:center;font-size:.85rem">Results are saved only on this device. Nothing is sent anywhere. Export them to share.</p><p>Participant: <b>' + r.id + '</b> • Pre-game quiz: <b>' + sc(r.pre) + '</b> • Post-game quiz: <b>' + sc(r.post) + '</b></p><table style="width:100%;font-size:.85rem;text-align:center"><tr><th>Level</th><th>Done</th><th>Attempts</th><th>Hints</th><th>Seconds</th></tr>' + rows + '</table><div class="dd-row"><button class="dd-btn" id="h-pre">PRE QUIZ</button><button class="dd-btn" id="h-post">POST QUIZ</button><button class="dd-btn" id="h-fb">FEEDBACK</button></div><div class="dd-row"><button class="dd-btn" id="h-json">EXPORT JSON</button><button class="dd-btn" id="h-csv">EXPORT CSV</button><button class="dd-btn" id="h-new">NEW PLAYER</button><button class="dd-btn main" id="h-x">CLOSE</button></div>');
  $d('h-x').onclick = () => o.classList.remove('on');
  $d('h-pre').onclick = () => { o.classList.remove('on'); ddQuiz('pre', ddHub); };
  $d('h-post').onclick = () => { o.classList.remove('on'); ddQuiz('post', ddHub); };
  $d('h-fb').onclick = () => { o.classList.remove('on'); ddFeedback(); };
  $d('h-json').onclick = () => ddDownload('lost-kingdom-playtest-' + r.id + '.json', JSON.stringify(ddR(), null, 2), 'application/json');
  $d('h-csv').onclick = () => ddDownload('lost-kingdom-playtest-' + r.id + '.csv', ddCSV(), 'text/csv');
  let armed = false;
  $d('h-new').onclick = () => { if (!armed) { armed = true; $d('h-new').textContent = 'SURE? PRESS AGAIN'; $d('h-new').style.borderColor = '#f87171'; return; } try { localStorage.removeItem('dd_research'); } catch (e) {} ddHub(); };
};
{ const b = $d('btn-map-playtest'); if (b) b.onclick = ddHub; }

// ---------- map: daily toggle + share card ----------
{ const b = $d('btn-map-playtest'); if (b) b.insertAdjacentHTML('afterend', ' <button class="runic-btn" id="gz-daily"></button> <button class="runic-btn accent-teal" id="gz-share">SHARE</button>'); }
function gzDailyBtn() { const b = $d('gz-daily'); if (b) { b.textContent = gzDM.on ? '📅 DAILY #' + gzDayNum() : '🎲 FREE PLAY'; b.title = gzDM.on ? 'Everyone gets the same puzzles today. Click for random puzzles.' : 'Random puzzles each time. Click for today\'s daily puzzles.'; } }
gzDailyBtn();
$d('gz-daily').onclick = () => { gzDM.on = !gzDM.on; try { localStorage.setItem('gz_daily', gzDM.on ? '1' : '0'); } catch (e) {} gzDailyBtn(); showToast(gzDM.on ? 'Daily mode: same puzzles as everyone today' : 'Free play: random puzzles'); };
$d('gz-share').onclick = () => {
  const r = gzRes(), day = gzDM.on ? r[gzToday()] || {} : r.free || {};
  const row = [0, 1, 2, 3, 4].map(i => day[i] ? gzRankEmoji[day[i].rank] : '⬛').join('');
  const hearts = [0, 1, 2, 3, 4].reduce((s, i) => s + (day[i] ? day[i].h : 0), 0), done = Object.keys(day).length;
  const text = '🌧️ ECHO POINT ' + (gzDM.on ? '— Daily #' + gzDayNum() : '— Free play') + '\n' + row + '  ' + done + '/5 chapters\n⟲ ' + hearts + '/' + done * 3 + ' rewinds left\n' + [0, 1, 2, 3, 4].map(i => day[i] ? day[i].rank : '·').join(' ') + '\nthe numbers lied. I didn\'t. 🕯️';
  const o = ddOverlay('gz-sharebox', '<h2>Share your run</h2><pre style="background:#0a1020;border:1px solid #d4af37;border-radius:10px;padding:12px;font-size:1rem;white-space:pre-wrap;text-align:center">' + text.replace(/</g, '&lt;') + '</pre><p style="text-align:center;font-size:.8rem;color:#9ba3b5">🟩 S · 🟨 A · 🟧 B · 🟥 C · ⬛ not played</p><div class="dd-row"><button class="dd-btn main" id="gz-sh-copy">COPY</button><button class="dd-btn" id="gz-sh-x">CLOSE</button></div>');
  $d('gz-sh-copy').onclick = () => { (navigator.clipboard ? navigator.clipboard.writeText(text) : Promise.reject()).then(() => showToast('Copied! Paste it in the group chat.'), () => showToast('Select the text above and copy it.')); };
  $d('gz-sh-x').onclick = () => o.classList.remove('on');
};

// ---------- animation: smooth acceleration, dust, landing squash ----------
const gzMove = { run: 0, prevOn: true, dust: [], fc: 0 };
{ const _uw = updateWorld; updateWorld = function () {
    const mv = explorer.movingLeft || explorer.movingRight || explorer.targetX != null;
    gzMove.run = mv ? Math.min(20, gzMove.run + 1) : 0;
    explorer.speed = 1.2 + ((window.gzRunning ? 5.6 : 3.2) - 1.2) * (gzMove.run / 20);
    _uw();
    if (!gzMove.prevOn && J.on) { window.__ddLand = performance.now(); gzDustBurst(10); }
    gzMove.prevOn = J.on;
  }; }
function gzFeet() { return { x: explorer.x / 1000 * canvas.width, y: canvas.height * .77 - J.h }; }
function gzDustBurst(n) { if (gzRM()) return; const f = gzFeet(); for (let i = 0; i < n; i++) gzMove.dust.push({ x: f.x + (Math.random() - .5) * 16, y: f.y, vx: (Math.random() - .5) * 2.6, vy: -Math.random() * 1.4, r: 2 + Math.random() * 3, life: 1 }); }
{ const _de = drawExplorer; drawExplorer = function (c, x, gy, f, wf, acc) {
    const w = canvas.width, t = performance.now() / 1000, pal = REALMS[gameState.currentRegion].palette;
    // ground lighting and swaying tufts along the floor
    const gl = c.createLinearGradient(0, gy, 0, gy + 40); gl.addColorStop(0, 'rgba(255,255,255,.07)'); gl.addColorStop(1, 'rgba(255,255,255,0)'); c.fillStyle = gl; c.fillRect(0, gy, w, 40);
    if (!window.gzNoTufts) { c.save(); c.strokeStyle = pal.accent; c.lineWidth = 1.5; c.globalAlpha = .4;
    for (let i = 0; i < 34; i++) { const bx = (i * 293 % 1000) / 1000 * w, sw = Math.sin(t * 1.6 + i) * 3; c.beginPath(); c.moveTo(bx, gy); c.quadraticCurveTo(bx + sw * .5, gy - 6, bx + sw, gy - 10 - (i % 3) * 3); c.moveTo(bx + 4, gy); c.quadraticCurveTo(bx + 4 + sw * .5, gy - 5, bx + 6 + sw, gy - 8); c.stroke(); }
    c.restore(); }
    // footstep dust
    if (J.on && wf > 0 && !gzRM()) { gzMove.fc++; if (gzMove.fc % 7 === 0) { const ft = gzFeet(); gzMove.dust.push({ x: ft.x - f * 6, y: ft.y, vx: -f * (0.4 + Math.random() * .6), vy: -Math.random() * .7, r: 1.5 + Math.random() * 2, life: 1 }); } }
    gzMove.dust.forEach(d => { d.x += d.vx; d.y += d.vy; d.vy += .03; d.r += .08; d.life -= .03; c.fillStyle = 'rgba(200,190,170,' + Math.max(0, d.life * .35) + ')'; c.beginPath(); c.arc(d.x, d.y, d.r, 0, 6.28); c.fill(); });
    gzMove.dust = gzMove.dust.filter(d => d.life > 0);
    _de(c, x, gy, f, wf, acc);
  }; }
// Ari: glowing body, flapping wings, sparkle trail, eyes
const gzAri = { trail: [] };
drawAriaWisp = function (c, x, y, acc) {
  const t = performance.now() / 1000;
  gzAri.trail.push({ x, y }); if (gzAri.trail.length > 16) gzAri.trail.shift();
  gzAri.trail.forEach((p, i) => { const k = i / gzAri.trail.length; c.fillStyle = 'rgba(153,246,228,' + k * .35 + ')'; c.beginPath(); c.arc(p.x + Math.sin(t * 5 + i) * 1.5, p.y + Math.cos(t * 4 + i), 1 + k * 3, 0, 6.28); c.fill(); });
  c.save(); c.translate(x, y);
  c.globalCompositeOperation = 'lighter';
  const pul = 1 + Math.sin(t * 4) * .1, gg = c.createRadialGradient(0, 0, 1, 0, 0, 30 * pul); gg.addColorStop(0, 'rgba(153,246,228,.55)'); gg.addColorStop(1, 'rgba(45,212,191,0)'); c.fillStyle = gg; c.beginPath(); c.arc(0, 0, 30 * pul, 0, 6.28); c.fill();
  c.globalCompositeOperation = 'source-over';
  const fl = .35 + .65 * Math.abs(Math.sin(t * 16));
  c.fillStyle = 'rgba(204,251,241,.45)'; c.strokeStyle = 'rgba(153,246,228,.9)'; c.lineWidth = 1;
  [-1, 1].forEach(s => { c.save(); c.scale(s, fl); c.beginPath(); c.ellipse(10, -4, 10, 5, -.5, 0, 6.28); c.fill(); c.stroke(); c.beginPath(); c.ellipse(8, 3, 6, 3, .4, 0, 6.28); c.fill(); c.restore(); });
  c.shadowColor = '#2dd4bf'; c.shadowBlur = 16; c.fillStyle = '#ecfeff'; c.beginPath(); c.arc(0, 0, 6.5, 0, 6.28); c.fill(); c.shadowBlur = 0;
  c.fillStyle = acc; c.beginPath(); c.arc(0, 1.5, 3, 0, 6.28); c.fill();
  const look = explorer.facing; c.fillStyle = '#0f172a'; if ((t % 4.3) > .12) { c.beginPath(); c.arc(-2 + look, -1.5, 1.1, 0, 6.28); c.arc(2 + look, -1.5, 1.1, 0, 6.28); c.fill(); } else c.fillRect(-3 + look, -1.8, 6, .8);
  c.restore();
};
// collectibles: light beam + orbiting glints
{ const _dio = drawInteractiveObject; drawInteractiveObject = function (c, o, sx, gy, realm, near) {
    if (o.type === 'collectible' && !o.collected) { const bg = c.createLinearGradient(0, gy - 160, 0, gy); bg.addColorStop(0, 'rgba(255,255,255,0)'); bg.addColorStop(1, realm.palette.glow + '33'); c.fillStyle = bg; c.fillRect(sx - 14, gy - 160, 28, 160); }
    _dio(c, o, sx, gy, realm, near);
    if (o.type === 'collectible' && !o.collected) { const t = performance.now() / 1000; c.save(); c.fillStyle = '#fffbeb'; for (let i = 0; i < 3; i++) { const a = t * 2.2 + i * 2.09, gx = sx + Math.cos(a) * 20, gyy = gy - 38 + Math.sin(a) * 7, s = 1.5 + Math.sin(t * 6 + i) * .8; c.globalAlpha = .5 + .5 * Math.sin(a); c.beginPath(); c.moveTo(gx, gyy - s * 2); c.lineTo(gx + s * .6, gyy); c.lineTo(gx, gyy + s * 2); c.lineTo(gx - s * .6, gyy); c.closePath(); c.fill(); } c.restore(); }
  }; }
// depth: far ridge behind, drifting fog after
{ const _dre = drawRegionEnvironment; drawRegionEnvironment = function (c, ri, w, h, gy, par) {
    const t = performance.now() / 1000, pal = REALMS[ri].palette;
    c.save(); c.fillStyle = 'rgba(0,0,0,.28)'; c.beginPath(); c.moveTo(0, gy);
    for (let x = 0; x <= w; x += 12) { const wx = x + par * .15; c.lineTo(x, gy - 150 - Math.sin(wx * .004 + ri) * 45 - Math.sin(wx * .013 + ri * 2) * 18 - Math.sin(wx * .031) * 6); }
    c.lineTo(w, gy); c.closePath(); c.fill(); c.restore();
    _dre(c, ri, w, h, gy, par);
    c.save(); c.globalCompositeOperation = 'lighter';
    for (let k = 0; k < 3; k++) { const fx = ((t * (8 + k * 5) + k * 400) % (w + 600)) - 300, fy = gy - 40 - k * 50, fg = c.createRadialGradient(fx, fy, 10, fx, fy, 260); fg.addColorStop(0, pal.glow + '14'); fg.addColorStop(1, pal.glow + '00'); c.fillStyle = fg; c.fillRect(fx - 260, fy - 120, 520, 240); }
    c.restore();
  }; }
// camera shake + foreground silhouettes for depth
{ const _rw = renderWorld; renderWorld = function () {
    const sh = gzShake.a;
    if (sh > .3) { ctx.save(); ctx.translate((Math.random() - .5) * sh, (Math.random() - .5) * sh); gzShake.a *= .86; } else gzShake.a = 0;
    _rw();
    const w = canvas.width, h = canvas.height, par = ((explorer.x - 500) / 1000) * 60;
    ctx.fillStyle = 'rgba(2,4,10,.85)';
    [[-.02, 70], [.97, 90], [.55, 40]].forEach(([fx, r], i) => { const x = fx * w - par * 1.4; ctx.beginPath(); ctx.ellipse(x, h + 10, r * 1.6, r, 0, 0, 6.28); ctx.fill(); ctx.beginPath(); ctx.ellipse(x + r * .9, h + 18, r, r * .8, 0, 0, 6.28); ctx.fill(); });
    if (sh > .3) ctx.restore();
  }; }
gzHpRender();

// ---------- stale notes rewritten (Star Path note gave old slider steps; Forest note gave away k = 3) ----------
openStarInscription = function () {
  const r2 = gameState.regions[2]; r2.loreScrollRead = true; soundFX.playMechanismClick(); saveGameState();
  openAncientModal('Headline Note', '<div class="ancient-carving-box"><p style="line-height:1.7;color:var(--parchment)">Pinned to a tree: a viral headline — <b>"Buying ice cream makes people go swimming!"</b><br><br>The Star Map shows data as stars. <b>r</b> is a score from −1 to +1: near +1 = rise together, near −1 = one up while the other goes down, near 0 = no link.<br><br>Two things rising together is a <b>correlation</b>. It does not tell you <b>why</b>. Before you believe the headline, ask: could something else be driving both?</p></div>');
};
openWildsInscription = function () {
  const r3 = gameState.regions[3]; r3.scrollRead = true; soundFX.playMechanismClick(); saveGameState();
  openAncientModal('Old Stone Note', '<div class="ancient-carving-box"><p style="line-height:1.7;color:var(--parchment)">Nobody knows how many kinds of creature live in this forest. Two? Three? Four?<br><br>K-means sorts them with <b>k</b> group centres (◆). Repeat:<br>1. Every creature joins its <b>nearest</b> centre.<br>2. Every centre moves to the <b>middle</b> of its group.<br>When the centres stop moving, that run is done.<br><br>Try different values of k. More groups always look "tighter", so the tightest is not automatically the best.</p></div>');
};
{ const _g2 = getRegionWorldObjects; getRegionWorldObjects = function (i) { const o = _g2(i); o.forEach(x => { if (x.id === 'stele_2') x.label = 'Headline Note'; if (x.id === 'boss_m') x.label = 'Prediction Staff (Boss)'; }); return o; }; }
DD_TARGET[4] = 'Prediction Staff';
{ const b = $d('gz-share'); if (b && b.parentNode) { b.parentNode.style.flexWrap = 'wrap'; b.parentNode.style.justifyContent = 'flex-end'; } }

// ---------- Ari's bubble sits above the explorer instead of covering them ----------
updateAriaBubblePosition = function (sx, sy) {
  const b = $d('aria-bubble'); if (!b || b.style.display === 'none') return;
  const bh = b.offsetHeight || 110;
  b.style.left = Math.max(16, Math.min(innerWidth - 300, sx - 120)) + 'px';
  b.style.top = Math.max(110, sy - bh - 70) + 'px';
};
// ---------- K-means: an empty group's centre jumps to the worst-fitting creature (standard fix) ----------
{ const _ku = AM.kMeansUpdateCentroids.bind(AM); AM.kMeansUpdateCentroids = function (assigned, cur) {
    const next = _ku(assigned, cur);
    next.forEach((c, i) => { if (!assigned.some(p => p.cluster === i) && assigned.length) { const far = assigned.reduce((a, p) => p.dist > a.dist ? p : a, assigned[0]); next[i] = { ...c, x: far.x, y: far.y }; } });
    return next; }; }
