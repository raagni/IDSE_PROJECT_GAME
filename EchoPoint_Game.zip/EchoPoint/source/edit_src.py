import re,sys
# Usage: copy base_game.html to echo_point.html, then run: python3 edit_src.py echo_point.html
p=sys.argv[1]; s=open(p,encoding='utf-8').read()
def rep(a,b,count=None):
    global s
    n=s.count(a)
    assert n>0, "NOT FOUND: "+a[:80]
    if count: assert n==count,(a[:60],n)
    s=s.replace(a,b)
rep('(<span id="hud-codex-count">0</span>/7)','(<span id="hud-codex-count">0</span>/8)')
rep('${codexCount} / 7','${codexCount} / 8')
rep('A kingdom lost its power. Five magic crystals are hidden across the land. Find them all and bring the light back!',
    'The kingdom&rsquo;s light is gone. Five crystals, five data puzzles, one boss. Use real numbers to beat the lies, the glitches and the monster.')
for i,lab in enumerate(['Number Stones [14, 42]','Number Stones [22, 38]','Number Stones [25, 25]','Number Stones [31, 54]','Number Stones [34, 45]']):
    rep(lab,'Pay Slip %d'%(i+1),2)
rep('(${count}/5 clusters found)','(${count}/5 found)')
rep('Go to the Stone Table. Add a very big number and see which one changes the most!',
    'At the Stone Table: predict first, then test it yourself. Which one gets dragged around by a single giant value?')
rep('Chronos Tablet II (Charges III & IV)','Old Tablet 2 (Attacks 3 & 4)')
rep('Chronos Tablet III (Charges V & VI)','Old Tablet 3 (Attacks 5 & 6)')
rep("<li>Fit a line to past data (linear regression) and use it to predict.</li></ol>",
    "<li>Fit a line to past data (linear regression) and use it to predict.</li><li>Explain overfitting (a model that fits old data perfectly can predict new data badly) and why predictions far from the data are less certain.</li></ol>")
rep('ordinary least-squares linear regression.','ordinary least-squares linear regression, overfitting and extrapolation.')
rep('<strong>Hint (H) for Hint:</strong>','<strong>Hint:</strong>')
rep('title="Hint (H) for Whispered Guidance (H)"','title="Hint (H)"')
rep('You solved every puzzle by looking at the data, testing ideas and checking the facts. Great job, hero!',
    'You beat every puzzle by testing ideas and checking the evidence, not by guessing. That is literally what data scientists do.')
for a,b in [("'Alpha Heat Crystals'","'Heat Crystal 1'"),("'Beta Core Crystals'","'Heat Crystal 2'"),("collectStarShard(0, 'Northern Star')","collectStarShard(0, 'North Star Piece')"),("collectStarShard(2, 'Astrolabe Dial')","collectStarShard(2, 'Star Dial')")]:
    rep(a,b)
# replace base character renderer
a=s.index('function drawExplorer(ctx, x, groundY, facing, walkFrame, accentColor) {')
b=s.index('function drawAriaWisp(ctx, x, y, accentColor) {')
s=s[:a]+open('./explorer.js',encoding='utf-8').read()+'\n'+s[b:]
# append patch script
s=s.replace('</body>\n</html>',''.join('<script>\n'+open('./'+f,encoding='utf-8').read()+'\n</script>\n' for f in ('patch.js','thriller.js','fx.js'))+'</body>\n</html>')
open(p,'w',encoding='utf-8').write(s)
print('ok')
