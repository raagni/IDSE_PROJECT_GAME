// ============================================================================
// v4: adaptive music score, stingers, footsteps, cinematic camera, idle life,
// evidence fly-in, and an animated "Mind Palace" replay of each concept.
// Names start with mx.
// ============================================================================

// ---------------------------------------------------------------- adaptive score
const MX = { on: false, next: 0, step: 0, mode: 'explore', lastCameo: null };
const mxProg = [ // chord roots + quality per chapter (MIDI), moody minor progressions
  [[57, 'm'], [53, 'M'], [48, 'M'], [55, 'M']],   // diner: Am F C G
  [[50, 'm'], [46, 'M'], [43, 'm'], [45, 'M']],   // basement: Dm Bb Gm A
  [[52, 'm'], [48, 'M'], [55, 'M'], [50, 'M']],   // radio: Em C G D
  [[48, 'm'], [44, 'M'], [41, 'm'], [43, 'M']],   // woods: Cm Ab Fm G
  [[45, 'm'], [43, 'M'], [41, 'M'], [40, 'M']]];  // lighthouse: Am G F E
const mxHz = m => 440 * Math.pow(2, (m - 69) / 12);
const mxChord = (r, q) => [r, r + (q === 'm' ? 3 : 4), r + 7];
function mxStart() {
  soundFX.init(); const A = soundFX.ctx; if (!A || MX.on) return; MX.on = true;
  MX.master = A.createGain(); MX.master.gain.value = 0;
  const comp = A.createDynamicsCompressor(); comp.threshold.value = -18; comp.ratio.value = 3;
  MX.master.connect(comp); comp.connect(A.destination);
  // reverb from a generated impulse
  const len = A.sampleRate * 2.8, ir = A.createBuffer(2, len, A.sampleRate);
  for (let ch = 0; ch < 2; ch++) { const d = ir.getChannelData(ch); for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 2.6); }
  MX.rev = A.createConvolver(); MX.rev.buffer = ir; const rg = A.createGain(); rg.gain.value = .55; MX.rev.connect(rg); rg.connect(MX.master);
  // echo for the piano
  MX.dly = A.createDelay(1); MX.dly.delayTime.value = .42; const fb = A.createGain(); fb.gain.value = .33; const dl = A.createBiquadFilter(); dl.type = 'lowpass'; dl.frequency.value = 2200;
  MX.dly.connect(dl); dl.connect(fb); fb.connect(MX.dly); dl.connect(MX.master); dl.connect(MX.rev);
  MX.next = A.currentTime + .2;
  setInterval(mxTick, 90);
}
function mxVoice(f, t0, dur, type, vol, opts) {
  const A = soundFX.ctx, o = A.createOscillator(), g = A.createGain(); o.type = type; o.frequency.setValueAtTime(f, t0);
  if (opts && opts.detune) o.detune.value = opts.detune;
  let node = o; if (opts && opts.lp) { const f2 = A.createBiquadFilter(); f2.type = 'lowpass'; f2.frequency.value = opts.lp; o.connect(f2); node = f2; }
  node.connect(g);
  const atk = (opts && opts.atk) || .01; g.gain.setValueAtTime(.0001, t0); g.gain.exponentialRampToValueAtTime(vol, t0 + atk); g.gain.exponentialRampToValueAtTime(.0001, t0 + dur);
  g.connect(MX.master); if (opts && opts.rev) g.connect(MX.rev); if (opts && opts.dly) g.connect(MX.dly);
  o.start(t0); o.stop(t0 + dur + .05);
}
function mxClick(t0, vol, freq) { const A = soundFX.ctx; if (!tzAmb.noise) return; const s = A.createBufferSource(); s.buffer = tzAmb.noise; const f = A.createBiquadFilter(); f.type = 'highpass'; f.frequency.value = freq || 6000; const g = A.createGain(); g.gain.setValueAtTime(vol, t0); g.gain.exponentialRampToValueAtTime(.0001, t0 + .05); s.connect(f); f.connect(g); g.connect(MX.master); s.start(t0); s.stop(t0 + .08); }
function mxMode() {
  const modal = $d('ancient-modal').classList.contains('active');
  if (document.body.classList.contains('tz-cut-on')) return 'cut';
  if ($d('screen-title').classList.contains('active') || $d('screen-map').classList.contains('active')) return 'menu';
  if (modal && gameState.currentRegion === 4) return 'boss';
  if (modal) return 'puzzle';
  return 'explore';
}
function mxTick() {
  const A = soundFX.ctx; if (!A) return;
  const mode = mxMode(); MX.mode = mode;
  const vol = soundFX.muted ? 0 : soundFX.musicVol * (mode === 'cut' ? .55 : mode === 'menu' ? .7 : 1);
  MX.master.gain.setTargetAtTime(vol * .9, A.currentTime, .4);
  if (tzWx.cameo && tzWx.cameo !== MX.lastCameo) { MX.lastCameo = tzWx.cameo; mxSting('dread'); }
  const bpm = mode === 'boss' ? 92 : mode === 'puzzle' ? 80 : 70, eighth = 60 / bpm / 2;
  const prog = mxProg[gameState.currentRegion] || mxProg[0];
  while (MX.next < A.currentTime + .35) {
    const t0 = MX.next, s = MX.step, bar = Math.floor(s / 8) % 4, e = s % 8, [root, q] = prog[bar], ch = mxChord(root, q);
    if (e === 0) { // pad + bass at each bar
      ch.forEach((n, i) => { mxVoice(mxHz(n), t0, eighth * 8.6, 'sawtooth', .022, { detune: -7, lp: mode === 'puzzle' || mode === 'boss' ? 1400 : 800, atk: 1.1, rev: true }); mxVoice(mxHz(n), t0, eighth * 8.6, 'sawtooth', .022, { detune: 7, lp: 800, atk: 1.1, rev: true }); });
      mxVoice(mxHz(root - 12), t0, eighth * 7, 'sine', .11, { atk: .05 });
    }
    if (e === 4) mxVoice(mxHz(root - 12), t0, eighth * 3.5, 'triangle', .06, { atk: .03 });
    // piano-like arpeggio
    const pat = [0, 1, 2, 1, 2, 0, 1, 2], note = ch[pat[e]] + 12 + (e === 6 && Math.random() < .3 ? 12 : 0);
    if (Math.random() < (mode === 'explore' || mode === 'menu' ? .7 : .9)) mxVoice(mxHz(note), t0, 1.4, 'triangle', mode === 'cut' ? .03 : .045, { rev: true, dly: true });
    if (mode === 'puzzle' || mode === 'boss') { mxClick(t0, e % 2 ? .02 : .05, 7000); }       // ticking clock
    if (mode === 'boss') { mxVoice(mxHz(root - 24), t0, eighth * .9, 'sawtooth', .05, { lp: 300 }); if (e === 0 || e === 3) { soundFX.playTone(52, .2, 'sine', .5, t0 - A.currentTime); } }
    MX.next += eighth; MX.step++;
  }
}
function mxSting(kind) {
  const A = soundFX.ctx; if (!A || !MX.on || soundFX.muted) return; const t0 = A.currentTime + .02;
  if (kind === 'dread') { [0, 1, 6, 11].forEach(i => mxVoice(mxHz(45 + i), t0, 3, 'sawtooth', .03, { lp: 1200, atk: 1.2, rev: true })); mxVoice(40, t0, 2.5, 'sine', .25, { atk: .02 }); }
  if (kind === 'clue') { [69, 72, 76, 81, 84].forEach((n, i) => mxVoice(mxHz(n), t0 + i * .12, 2.2, 'triangle', .07, { rev: true, dly: true })); mxVoice(mxHz(45), t0, 3, 'sine', .12, {}); }
  if (kind === 'rewind') { [58, 59, 64].forEach(n => mxVoice(mxHz(n), t0, 1.2, 'square', .025, { lp: 2000, rev: true })); }
  if (kind === 'fail') { [33, 34, 39].forEach(n => mxVoice(mxHz(n), t0, 4, 'sawtooth', .06, { lp: 500, atk: .3, rev: true })); }
  if (kind === 'reveal') { [57, 60, 64, 69].forEach((n, i) => mxVoice(mxHz(n), t0 + i * .4, 3, 'sine', .06, { rev: true, atk: .3 })); }
}
{ const _s = soundFX.startAmbientLoop; soundFX.startAmbientLoop = function () { _s(); mxStart(); }; }
addEventListener('pointerdown', () => { tzAmb.start(); mxStart(); }, { once: true });
{ const _r = gzRedFlash; gzRedFlash = function () { _r(); mxSting('rewind'); }; }
{ const _f = gzLevelFail; gzLevelFail = function () { _f(); mxSting('fail'); }; }

// ---------------------------------------------------------------- cinematic camera (zooms in during dialogue)
const mxCam = { z: 1, fx: null, fy: null };
{ const _rw = renderWorld; renderWorld = function () {
    const w = canvas.width, h = canvas.height, gy = h * .77, H = tzH(), cut = document.body.classList.contains('tz-cut-on');
    let tz = 1, tfx = w / 2, tfy = h / 2;
    if (cut) { tz = 1.32; const px = explorer.x / 1000 * w; let ox = px; const sp = tzCutSpeaker();
      const npc = getRegionWorldObjects(gameState.currentRegion).find(o => o.type === 'npc' && o.cast === sp); if (npc) ox = npc.x / 1000 * w;
      const act = window.tzActors && window.tzActors.find(a => a.cast === sp); if (act) ox = act.x * w;
      tfx = (px + ox) / 2; tfy = gy - H * .55; }
    if (mxCam.fx == null) { mxCam.fx = tfx; mxCam.fy = tfy; }
    const k = gzRM() ? 1 : .06; mxCam.z += (tz - mxCam.z) * k; mxCam.fx += (tfx - mxCam.fx) * k; mxCam.fy += (tfy - mxCam.fy) * k;
    const z = mxCam.z, fx = Math.max(w / (2 * z), Math.min(w - w / (2 * z), mxCam.fx)), fy = Math.max(h / (2 * z), Math.min(h - h / (2 * z), mxCam.fy));
    ctx.save(); ctx.translate(w / 2, h / 2); ctx.scale(z, z); ctx.translate(-fx, -fy);
    _rw();
    ctx.restore();
    mxBreathDraw();
  }; }

// ---------------------------------------------------------------- footsteps, idle phone check, breath fog
const mxP = { idle: 0, breath: [], nextBreath: 0 };
{ const _dp = window.gzDrawPlayer; window.gzDrawPlayer = function (c, x, gy, f, wf, acc) {
    const before = tzP.ph;
    const moving = tzP.gait > .05 || !J.on;
    mxP.idle = moving ? 0 : mxP.idle + 1 / 60;
    const dark = [1, 3, 4].includes(gameState.currentRegion);
    tzP.pose = (!dark && mxP.idle > 6 && !document.body.classList.contains('tz-cut-on')) ? 'phone' : null;
    _dp(c, x, gy, f, wf, acc);
    if (J.on && tzP.gait > .1 && Math.floor(tzP.ph / Math.PI) !== Math.floor(before / Math.PI)) mxStep(x, gy);
    if (tzP.pose === 'phone') { c.save(); c.globalCompositeOperation = 'lighter'; const H = tzH(), px = x + f * H * .1, py = gy - H * .6; const g = c.createRadialGradient(px, py, 2, px, py, 60); g.addColorStop(0, 'rgba(147,197,253,.35)'); g.addColorStop(1, 'rgba(147,197,253,0)'); c.fillStyle = g; c.fillRect(px - 60, py - 60, 120, 120); c.restore(); }
    const t = tzT(); if (!tzIndoor(gameState.currentRegion) && t > mxP.nextBreath) { mxP.nextBreath = t + 2.4 + Math.random(); const H = tzH(); mxP.breath.push({ x: x + f * H * .14, y: gy - H * .9 - (J.h || 0), vx: f * .5, r: 3, a: .35 }); }
  }; }
function mxBreathDraw() { mxP.breath.forEach(b => { b.x += b.vx; b.y -= .25; b.r += .35; b.a -= .006; ctx.fillStyle = 'rgba(220,230,240,' + Math.max(0, b.a * .5) + ')'; ctx.beginPath(); ctx.arc(b.x, b.y, b.r, 0, 6.28); ctx.fill(); }); mxP.breath = mxP.breath.filter(b => b.a > 0); }
function mxStep(x, gy) {
  const A = soundFX.ctx; if (A && tzAmb.noise && !soundFX.muted) { const out = !tzIndoor(gameState.currentRegion), s = A.createBufferSource(); s.buffer = tzAmb.noise; const f = A.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = out ? 700 + Math.random() * 300 : 1800 + Math.random() * 600; f.Q.value = out ? 1.2 : 3; const g = A.createGain(), t0 = A.currentTime; g.gain.setValueAtTime(.0001, t0); g.gain.exponentialRampToValueAtTime((out ? .22 : .14) * soundFX.sfxVol * Math.min(1.4, tzP.gait), t0 + .01); g.gain.exponentialRampToValueAtTime(.0001, t0 + (out ? .16 : .07)); s.connect(f); f.connect(g); g.connect(A.destination); s.start(t0); s.stop(t0 + .2); }
  if (!tzIndoor(gameState.currentRegion)) tzWx.splash.push({ x, y: gy + 2, r: 2, a: .6 });
}

// ---------------------------------------------------------------- evidence flies into the bag
{ const _add = addInventoryRelic; addInventoryRelic = function (id, label, icon) {
    const had = gameState.inventory.some(it => it.id === id); _add(id, label, icon);
    if (had || gzRM()) return; const bar = $d('satchel-bar'); if (!bar || $d('bottom-hud').style.display !== 'flex') return;
    const sx = explorer.x / 1000 * innerWidth, sy = innerHeight * .77 - tzH() * .7, r = bar.getBoundingClientRect();
    const e = document.createElement('div'); e.textContent = '🗂️ ' + label; e.style.cssText = 'position:fixed;z-index:700;left:' + sx + 'px;top:' + sy + 'px;padding:4px 10px;border-radius:4px;background:#efe8da;color:#1c1917;font:bold 12px Courier New;box-shadow:0 8px 20px rgba(0,0,0,.6);transition:all .9s cubic-bezier(.5,-0.3,.4,1);pointer-events:none';
    document.body.appendChild(e); requestAnimationFrame(() => requestAnimationFrame(() => { e.style.left = (r.right - 80) + 'px'; e.style.top = (r.top + 4) + 'px'; e.style.transform = 'scale(.6) rotate(-8deg)'; e.style.opacity = '.2'; }));
    setTimeout(() => e.remove(), 1000);
  }; }

// ---------------------------------------------------------------- MIND PALACE: replay the concept with the player's own data
document.head.insertAdjacentHTML('beforeend', '<style>#mx-mp{width:100%;max-width:520px;display:block;margin:8px auto 4px;background:#05060a;border:1px solid rgba(225,29,72,.45);border-radius:4px}#mx-cap{text-align:center;font:italic .95rem Georgia;color:#fecdd3;min-height:2.6em;margin:2px 0 6px}.mx-lbl{text-align:center;font:bold .7rem Courier New;letter-spacing:.3em;color:#e11d48;margin-top:6px}</style>');
function mxMindPalace(i) {
  const card = document.querySelector('#dd-complete .dd-card'); if (!card) return;
  const pol = card.querySelector('.tz-polaroid'); const host = document.createElement('div');
  host.innerHTML = '<div class="mx-lbl">◈ MIND PALACE — REPLAYING YOUR EVIDENCE ◈</div><canvas id="mx-mp" width="520" height="190"></canvas><div id="mx-cap"></div><div style="text-align:center"><button class="dd-btn" id="mx-replay" style="padding:4px 14px;font-size:.8rem">↻ REPLAY</button></div>';
  (pol ? pol.after(host) : card.prepend(host));
  const cv = $d('mx-mp'), g = cv.getContext('2d'), W = 520, Hh = 190;
  let t0 = performance.now(), raf;
  const cap = s => { const c = $d('mx-cap'); if (c && c.textContent !== s) c.textContent = s; };
  const ease = k => k < 0 ? 0 : k > 1 ? 1 : k * k * (3 - 2 * k);
  const S = mxScenes[i](); mxSting('reveal');
  const loop = now => { if (!$d('mx-mp')) return; const t = (now - t0) / 1000; g.clearRect(0, 0, W, Hh); g.fillStyle = '#05060a'; g.fillRect(0, 0, W, Hh); S(g, t, ease, cap, W, Hh); raf = requestAnimationFrame(loop); };
  raf = requestAnimationFrame(loop);
  $d('mx-replay').onclick = () => { t0 = performance.now(); mxSting('reveal'); };
}
const mxScenes = [
  () => { // mean vs median with the actual pay list
    const base = (L1.base && L1.base.length ? L1.base : [18, 17, 17, 41, 20, 51, 29, 47, 40]).slice(), added = (L1.cur || []).filter(v => !base.includes(v)), big = added.length ? Math.max(...added) : Math.max(...base) * 6;
    const all = [...base, big], mx = big * 1.05, X = v => 30 + v / mx * 460;
    const m0 = AM.mean(base), d0 = AM.median(base), m1 = AM.mean(all), d1 = AM.median(all);
    return (g, t, E, cap) => {
      g.strokeStyle = 'rgba(255,255,255,.2)'; g.beginPath(); g.moveTo(20, 140); g.lineTo(500, 140); g.stroke();
      base.forEach((v, k) => { const a = E(t * 2 - k * .15); g.fillStyle = 'rgba(45,212,191,' + a + ')'; g.beginPath(); g.arc(X(v), 140 - k % 3 * 10, 6, 0, 6.28); g.fill(); });
      const drop = E(t - 2); if (t > 2) { g.fillStyle = '#e11d48'; g.beginPath(); g.arc(X(big), 20 + 120 * drop, 9, 0, 6.28); g.fill(); g.fillStyle = '#fecdd3'; g.font = '11px Courier New'; g.textAlign = 'center'; g.fillText("owner's pay", X(big), 12 + 120 * drop - 14); }
      const k = E(t - 3), mean = m0 + (m1 - m0) * k, med = d0 + (d1 - d0) * k;
      const mark = (v, col, lbl, y) => { g.strokeStyle = col; g.lineWidth = 2.5; g.beginPath(); g.moveTo(X(v), 60); g.lineTo(X(v), 150); g.stroke(); g.fillStyle = col; g.font = 'bold 12px Courier New'; g.textAlign = 'center'; g.fillText(lbl + ' ' + v.toFixed(1), X(v), y); };
      if (t > 1) { mark(med, '#2dd4bf', 'MEDIAN', 172); mark(mean, '#f472b6', 'MEAN', 55); }
      cap(t < 2 ? 'Nine ordinary workers. Mean and median sit close together.' : t < 3.2 ? 'Then the owner adds his own giant pay…' : 'The mean is dragged ' + (m1 - m0).toFixed(1) + ' to the right. The median moves only ' + (d1 - d0).toFixed(1) + '. That is how an "average" lies.');
    };
  },
  () => { // sudden jump vs steady climb
    const a = (FM.A && FM.A.find(s => s.odd) || { hist: [74, 76, 75, 77, 240] }).hist, b = (FM.B && FM.B.find(s => s.odd) || { hist: [78, 88, 120, 160, 196] }).hist, mx = Math.max(...a, ...b) * 1.1;
    return (g, t, E, cap) => {
      const draw = (h, x0, col, lbl, k) => { g.fillStyle = '#9ca3af'; g.font = '11px Courier New'; g.textAlign = 'left'; g.fillText(lbl, x0, 18); g.strokeStyle = col; g.lineWidth = 3; g.beginPath(); const n = Math.max(1, Math.floor(1 + k * (h.length - 1))); for (let j = 0; j < n; j++) { const px = x0 + j * 50, py = 170 - h[j] / mx * 140; j ? g.lineTo(px, py) : g.moveTo(px, py); } g.stroke(); for (let j = 0; j < n; j++) { g.fillStyle = col; g.beginPath(); g.arc(x0 + j * 50, 170 - h[j] / mx * 140, 4, 0, 6.28); g.fill(); } };
      draw(a, 20, '#f87171', 'FURNACE 1 · sensor history', E(t / 2)); draw(b, 280, '#fbbf24', 'FURNACE 2 · sensor history', E((t - 2) / 2));
      cap(t < 2.2 ? 'Furnace 1: normal, normal, normal… then a sudden impossible jump. A glitch.' : t < 4.5 ? 'Furnace 2: it climbs step by step. Real heat behaves like this.' : 'Same "outlier" on paper. Opposite stories. Always ask WHY before you delete.');
    };
  },
  () => { // correlation explained by a confounder
    const pts = (spGen('ice', DDSEED.star || 1) || []).map(p => ({ ...p })), cols = ['#38bdf8', '#fbbf24', '#f87171'];
    const X = v => 30 + v * 4.6, Y = v => 175 - v * 1.6;
    return (g, t, E, cap) => {
      const k = E(t - 2.5);
      pts.forEach(p => { g.fillStyle = k > .05 ? cols[p.band] : '#2dd4bf'; g.globalAlpha = E(t * 1.5); g.beginPath(); g.arc(X(p.x), Y(p.y), 5, 0, 6.28); g.fill(); }); g.globalAlpha = 1;
      const line = (P, col, a) => { if (P.length < 3) return; const f = AM.linearRegressionOLS(P); g.strokeStyle = col; g.globalAlpha = a; g.lineWidth = 2.5; g.beginPath(); const xs = P.map(p => p.x), lo = Math.min(...xs), hi = Math.max(...xs); g.moveTo(X(lo), Y(f.slope * lo + f.intercept)); g.lineTo(X(hi), Y(f.slope * hi + f.intercept)); g.stroke(); g.globalAlpha = 1; };
      if (t > 1) line(pts, '#f5d76e', 1 - k * .7);
      if (k > 0) [0, 1, 2].forEach(b => line(pts.filter(p => p.band === b), cols[b], k));
      g.fillStyle = '#9ca3af'; g.font = '11px Courier New'; g.textAlign = 'left'; g.fillText('ice cream sales →', 380, 186); g.fillText('swimmers ↑', 6, 14);
      cap(t < 2.5 ? 'Overall: a strong link, r = ' + ptsR(pts).toFixed(2) + '. The post says ice cream causes swimming.' : 'Colour by weather and look inside each group: the link almost vanishes. Hot days drive BOTH.');
    };
  },
  () => { // pings joining clusters
    const pts = REALMS[3].creatures.map(p => ({ x: p.x, y: p.y })), r = DDMath.rng(5), res = gzKm(pts, 3, r, 8), cols = ['#2dd4bf', '#f59e0b', '#c084fc'], asg = AM.kMeansAssign(pts, res.c);
    const X = v => 20 + v / 660 * 480, Y = v => 10 + v / 240 * 170;
    return (g, t, E, cap) => {
      const k = E((t - 1.5) / 1.5);
      asg.forEach((p, j) => { const c = res.c[p.cluster]; if (k > 0) { g.strokeStyle = cols[p.cluster]; g.globalAlpha = .4 * k; g.beginPath(); g.moveTo(X(p.x), Y(p.y)); g.lineTo(X(c.x), Y(c.y)); g.stroke(); g.globalAlpha = 1; } g.fillStyle = k > .5 ? cols[p.cluster] : '#9ca3af'; g.beginPath(); g.arc(X(p.x), Y(p.y), 4.5, 0, 6.28); g.fill(); });
      if (k > 0) res.c.forEach((c, j) => { g.strokeStyle = cols[j]; g.lineWidth = 2.5; g.beginPath(); g.arc(X(c.x), Y(c.y), 10 + 4 * Math.sin(t * 4), 0, 6.28); g.stroke(); });
      if (t > 3.5) { const far = res.c.reduce((a, c) => c.x > a.x ? c : a, res.c[0]); g.fillStyle = '#fecdd3'; g.font = 'bold 12px Courier New'; g.textAlign = 'center'; g.fillText('🗼 lighthouse', X(far.x), Y(far.y) - 16); }
      cap(t < 1.5 ? 'Dozens of pings. To the county, it looked like noise.' : t < 3.5 ? 'Each ping joins its nearest centre. Each centre moves to the middle of its group.' : 'Three tight groups = three real places. One more group would only split a place in half.');
    };
  },
  () => { // line vs overfit curve vs the future
    const tr = gzCA.train.length ? gzCA.train : [{ x: 1, y: 18 }, { x: 2, y: 25 }, { x: 3, y: 31 }, { x: 4, y: 38 }, { x: 5, y: 44 }, { x: 6, y: 51 }], fut = gzCA.w && gzCA.w[2] ? gzCA.w[2] : { x: 9, y: 70 }, f = AM.linearRegressionOLS(tr), L = x => f.slope * x + f.intercept;
    const yMax = Math.max(...tr.map(p => p.y), fut.y) * 1.35, X = v => 30 + v / 10 * 460, Y = v => 175 - v / yMax * 160;
    return (g, t, E, cap) => {
      g.save(); g.beginPath(); g.rect(0, 0, 520, 190); g.clip();
      tr.forEach(p => { g.fillStyle = '#2dd4bf'; g.beginPath(); g.arc(X(p.x), Y(p.y), 5, 0, 6.28); g.fill(); });
      const k1 = E(t - .5); g.strokeStyle = '#f5d76e'; g.lineWidth = 2.5; g.beginPath(); g.moveTo(X(.5), Y(L(.5))); g.lineTo(X(.5 + 9.3 * k1), Y(L(.5 + 9.3 * k1))); g.stroke();
      const k2 = E((t - 1.8) / 1.5); if (k2 > 0) { g.strokeStyle = '#f472b6'; g.setLineDash([6, 4]); g.beginPath(); for (let x = .7; x <= .7 + 8.9 * k2; x += .05) { const y = gzLag(tr, x); x < .75 ? g.moveTo(X(x), Y(y)) : g.lineTo(X(x), Y(y)); } g.stroke(); g.setLineDash([]); }
      if (t > 3.6) { const b = E((t - 3.6) * 2); g.fillStyle = '#e11d48'; g.beginPath(); g.arc(X(fut.x), Y(fut.y), 7 * b, 0, 6.28); g.fill(); g.fillStyle = '#fecdd3'; g.font = 'bold 11px Courier New'; g.textAlign = 'center'; g.fillText('what really happened', X(fut.x), Y(fut.y) + 20); }
      g.restore();
      cap(t < 1.8 ? 'A simple line through six nights. Small errors, but it follows the pattern.' : t < 3.6 ? 'The "perfect" curve hits every old point… and explodes the moment it leaves the data.' : 'The future landed near the line. Fitting the past perfectly ≠ predicting the future. That is overfitting.');
    };
  }];
{ const _slc = showLevelComplete; showLevelComplete = function (i) { _slc(i); mxSting('clue'); try { mxMindPalace(i); } catch (e) { console.warn('mind palace', e); } }; }
