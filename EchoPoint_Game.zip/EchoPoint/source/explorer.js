function drawExplorer(ctx, x, groundY, facing, walkFrame, accentColor) {
  if (window.gzDrawPlayer) return window.gzDrawPlayer(ctx, x, groundY, facing, walkFrame, accentColor);
  // Articulated explorer: two-segment legs and arms, flowing cloak and scarf,
  // breathing idle, blink, airborne tuck, landing squash and a flickering lantern.
  const now = performance.now();
  const t = now / 1000;
  const J2 = (typeof J !== 'undefined') ? J : { on: true, vy: 0 };
  const air = !J2.on;
  const vy = J2.vy || 0;
  const moving = walkFrame > 0 && !air;
  const ph = walkFrame * 1.05;
  const land = window.__ddLand ? Math.max(0, 1 - (now - window.__ddLand) / 240) : 0;
  const squash = Math.sin(land * Math.PI) * 0.16;
  const stretch = air ? Math.min(0.09, Math.abs(vy) * 0.01) : 0;
  const bob = moving ? Math.abs(Math.sin(ph)) * 2.6 : Math.sin(t * 2.1) * 0.9;
  const lean = moving ? 0.1 : (air ? 0.05 : 0);
  const S = 1.5;

  ctx.save();
  ctx.translate(x, groundY);
  if (!air) {
    const sg = ctx.createRadialGradient(0, 2, 2, 0, 2, 24);
    sg.addColorStop(0, 'rgba(0,0,0,0.55)'); sg.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = sg; ctx.beginPath(); ctx.ellipse(0, 2, 24, 6, 0, 0, Math.PI * 2); ctx.fill();
  }
  ctx.scale(facing * S * (1 + squash * 0.7), S * (1 - squash + stretch));
  ctx.translate(0, -bob);
  ctx.lineCap = 'round'; ctx.lineJoin = 'round';

  const hipY = -30, shY = -53;
  const limb = (x0, y0, a1, l1, a2, l2, w, col) => {
    const kx = x0 + Math.sin(a1) * l1, ky = y0 + Math.cos(a1) * l1;
    const fx = kx + Math.sin(a2) * l2, fy = ky + Math.cos(a2) * l2;
    ctx.strokeStyle = col; ctx.lineWidth = w;
    ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(kx, ky); ctx.lineTo(fx, fy); ctx.stroke();
    return { kx, ky, fx, fy };
  };
  const legAngles = (off) => {
    if (air) { const up = vy > 0; return [(up ? 0.75 : 0.35) - off * 0.35, (up ? -0.55 : -0.15) - off * 0.25]; }
    if (!moving) return [0.04 - off * 0.08, 0.02 - off * 0.08];
    const p = ph + off * Math.PI;
    const thigh = Math.sin(p) * 0.6;
    const bend = (1 + Math.cos(p)) * 0.5 * 0.95;
    return [thigh, thigh - bend];
  };
  const boot = (f, a, col) => {
    ctx.save(); ctx.translate(f.fx, f.fy); ctx.rotate(-a * 0.3);
    ctx.fillStyle = col; ctx.beginPath(); ctx.roundRect(-3.5, -2.5, 10, 5, 2.5); ctx.fill(); ctx.restore();
  };

  // far leg
  let la = legAngles(1);
  let f1 = limb(-1, hipY, la[0], 15, la[1], 15, 5.5, '#334155');
  boot(f1, la[1], '#1e1b2e');

  // far arm swings against the far leg
  const armSw = moving ? Math.sin(ph) * 0.65 : (air ? -1.6 : Math.sin(t * 2.1) * 0.05);
  limb(-1, shY + 4, armSw, 11, armSw + (moving ? 0.5 : 0.3), 11, 4.5, '#2b3a55');

  // cloak (behind body), trailing with motion and gently waving
  const sway = moving ? 7 + Math.sin(t * 9) * 2.2 : (air ? (vy > 0 ? -4 : 9) : Math.sin(t * 1.7) * 2);
  const hemY = hipY + (air && vy < 0 ? 10 : 16);
  const cg = ctx.createLinearGradient(0, shY, -18, hemY);
  cg.addColorStop(0, '#1f3b63'); cg.addColorStop(1, '#0b1730');
  ctx.fillStyle = cg;
  ctx.beginPath();
  ctx.moveTo(4, shY + 1);
  ctx.quadraticCurveTo(-6, shY + 12, -10 - sway * 0.6, hipY + 4);
  ctx.quadraticCurveTo(-14 - sway, hemY + Math.sin(t * 7) * 1.5, -4 - sway * 0.6, hemY + 2);
  ctx.quadraticCurveTo(2, hipY + 10, 6, hipY + 2);
  ctx.closePath(); ctx.fill();
  ctx.strokeStyle = 'rgba(212,175,55,0.75)'; ctx.lineWidth = 1.2; ctx.stroke();

  // near leg
  la = legAngles(0);
  const f0 = limb(2, hipY, la[0], 15, la[1], 15, 6, '#475569');
  boot(f0, la[1], '#251f38');

  // torso (tunic) with lean
  ctx.save(); ctx.rotate(lean);
  const tg = ctx.createLinearGradient(-8, shY, 8, hipY);
  tg.addColorStop(0, '#24456f'); tg.addColorStop(1, '#152a48');
  ctx.fillStyle = tg;
  ctx.beginPath();
  ctx.moveTo(-6, shY + 2); ctx.quadraticCurveTo(0, shY - 2, 7, shY + 2);
  ctx.lineTo(8, hipY + 3); ctx.quadraticCurveTo(1, hipY + 6, -6, hipY + 3); ctx.closePath(); ctx.fill();
  ctx.strokeStyle = 'rgba(212,175,55,0.55)'; ctx.lineWidth = 1; ctx.stroke();
  // belt
  ctx.fillStyle = '#7e651e'; ctx.fillRect(-6, hipY - 3, 14, 3);
  ctx.fillStyle = '#f5d76e'; ctx.fillRect(0, hipY - 3.5, 3, 4);

  // scarf tails in the level colour
  ctx.strokeStyle = accentColor; ctx.lineWidth = 3.2;
  ctx.beginPath(); ctx.moveTo(-2, shY + 1);
  const wv = moving ? 1 : 0.4;
  ctx.bezierCurveTo(-8, shY + 2 + Math.sin(t * 10) * 2 * wv, -13 - sway * 0.4, shY + Math.sin(t * 8 + 1) * 3 * wv,
                    -19 - sway * 0.7, shY + 4 + Math.sin(t * 9 + 2) * 3 * wv);
  ctx.stroke();

  // head + hood
  const hx = 3, hy = shY - 10;
  ctx.fillStyle = '#e9c9a6';
  ctx.beginPath(); ctx.arc(hx + 1, hy + 1, 7.5, 0, Math.PI * 2); ctx.fill();
  ctx.fillStyle = '#1a2f52';
  ctx.beginPath();
  ctx.moveTo(hx + 7, hy - 3);
  ctx.quadraticCurveTo(hx + 2, hy - 13, hx - 7, hy - 7);
  ctx.quadraticCurveTo(hx - 12 - sway * 0.2, hy + 2, hx - 6, hy + 9);
  ctx.quadraticCurveTo(hx - 3, hy + 2, hx - 1, hy - 2);
  ctx.quadraticCurveTo(hx + 3, hy - 5, hx + 7, hy - 3);
  ctx.fill();
  ctx.strokeStyle = 'rgba(212,175,55,0.7)'; ctx.lineWidth = 1; ctx.stroke();
  // eye with blink
  const blink = (t % 3.7) < 0.13;
  ctx.fillStyle = '#0f172a';
  if (blink) { ctx.fillRect(hx + 4, hy + 0.5, 3, 1); }
  else { ctx.beginPath(); ctx.arc(hx + 5.5, hy + 0.5, 1.4, 0, Math.PI * 2); ctx.fill(); }
  ctx.fillStyle = 'rgba(244,114,182,0.35)'; ctx.beginPath(); ctx.arc(hx + 4.5, hy + 4, 1.8, 0, Math.PI * 2); ctx.fill();
  ctx.restore();

  // near arm holding the lantern, lantern swings like a pendulum
  const naA = moving ? 0.95 - Math.sin(ph) * 0.18 : (air ? 1.5 : 0.85 + Math.sin(t * 2.1) * 0.04);
  const arm = limb(3, shY + 4, naA, 10, naA - 0.9, 9, 4.8, '#3b5278');
  const swing = moving ? Math.sin(ph * 1 + 0.6) * 0.35 : Math.sin(t * 1.6) * 0.12 + (air ? -vy * 0.04 : 0);
  ctx.save(); ctx.translate(arm.fx, arm.fy); ctx.rotate(swing);
  ctx.strokeStyle = '#d4af37'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(0, 5); ctx.stroke();
  const flick = 0.85 + Math.sin(t * 23) * 0.06 + Math.sin(t * 37) * 0.05;
  ctx.globalCompositeOperation = 'lighter';
  const lg = ctx.createRadialGradient(0, 10, 1, 0, 10, 46 * flick);
  lg.addColorStop(0, 'rgba(255,236,170,0.55)'); lg.addColorStop(0.35, 'rgba(245,215,110,0.16)'); lg.addColorStop(1, 'rgba(245,215,110,0)');
  ctx.fillStyle = lg; ctx.beginPath(); ctx.arc(0, 10, 46 * flick, 0, Math.PI * 2); ctx.fill();
  ctx.globalCompositeOperation = 'source-over';
  ctx.fillStyle = '#7e651e'; ctx.fillRect(-3.5, 4, 7, 2);
  ctx.fillStyle = 'rgba(255,248,220,' + (0.85 * flick) + ')'; ctx.beginPath(); ctx.roundRect(-3, 6, 6, 8, 2); ctx.fill();
  ctx.strokeStyle = '#d4af37'; ctx.strokeRect(-3, 6, 6, 8);
  ctx.restore();

  ctx.restore();
}
